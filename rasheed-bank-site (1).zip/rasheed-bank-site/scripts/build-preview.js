'use strict';
/**
 * Builds two standalone, double-clickable HTML files in /preview:
 *   preview/site.html   – the public website
 *   preview/admin.html  – the admin panel (runs against an in-memory mock API, nothing is saved)
 * No server needed. Usage:  node scripts/build-preview.js
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const PUB = path.join(ROOT, 'public');
const OUT = path.join(ROOT, 'preview');
fs.mkdirSync(OUT, { recursive: true });

const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.gif': 'image/gif' };
const read = (p) => fs.readFileSync(path.join(PUB, p), 'utf8');

// every image the pages may reference -> data URI (logo is downscaled to keep the files light)
const assets = {};
for (const dir of ['uploads', 'assets']) {
  for (const f of fs.readdirSync(path.join(PUB, dir))) {
    const ext = path.extname(f).toLowerCase(); if (!MIME[ext]) continue;
    const file = path.join(PUB, dir, f);
    let buf = fs.readFileSync(file);
    if (f === 'logo.png') {
      try { buf = execFileSync('convert', [file, '-resize', '256x256', 'png:-'], { maxBuffer: 1 << 24 }); } catch (e) { /* keep original */ }
    }
    assets[`/${dir}/${f}`] = `data:${MIME[ext]};base64,${buf.toString('base64')}`;
  }
}
const content = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'content.json'), 'utf8'));

// in JS sources, quoted asset paths become lookups into window.__A
const jsify = (src) => src.replace(/(['"])(\/(?:uploads|assets)\/[\w.\-]+)\1/g, (m, q, p) => `__A[${JSON.stringify(p)}]`);

const mock = `
(function () {
  var A = ${JSON.stringify(assets)};
  window.__A = A; window.__PREVIEW__ = true;
  var DB = ${JSON.stringify(content)};
  var logged = true;
  var media = Object.keys(A).filter(function (k) { return k.indexOf('/uploads/') === 0; }).map(function (k) { return { name: k.split('/').pop(), url: k, size: 0, mtime: 0 }; });
  var slug = function (s) { return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'service'; };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var res = function (status, body) {
    var txt = JSON.stringify(body).replace(/\\/(uploads|assets)\\/[\\w.\\-]+/g, function (m) { return A[m] || m; });
    return new Response(txt, { status: status, headers: { 'Content-Type': 'application/json' } });
  };
  window.confirm = function () { return true; };
  var back = function (s) { return typeof s === 'string' ? s : s; };
  window.fetch = function (url, opts) {
    opts = opts || {}; var m = (opts.method || 'GET').toUpperCase(); var b = opts.body ? JSON.parse(opts.body) : {};
    var u = String(url); var p;
    return new Promise(function (resolve) { setTimeout(function () { resolve(route()); }, 60); });
    function route() {
      if (u === '/api/content') return res(200, { settings: DB.settings, services: DB.services.filter(function (s) { return s.visible !== false; }) });
      if (u === '/api/login') { logged = true; return res(200, { ok: true, user: 'admin' }); }
      if (u === '/api/logout') { logged = false; return res(200, { ok: true }); }
      if (u === '/api/me') return logged ? res(200, { user: 'admin' }) : res(401, { error: 'unauthorized' });
      if (!logged) return res(401, { error: 'unauthorized' });
      if (u === '/api/admin/content') return res(200, DB);
      if (u === '/api/settings' && m === 'PUT') { DB.settings = b; return res(200, { ok: true, settings: DB.settings }); }
      if (u === '/api/services' && m === 'POST') {
        if (!((b.name && b.name.ar || '').trim() || (b.name && b.name.en || '').trim())) return res(400, { error: 'name_required' });
        var s = clone(b); s.id = Math.random().toString(16).slice(2, 14).padEnd(12, '0'); s.slug = slug(s.name.en || s.id) + '-' + DB.services.length; DB.services.push(s); return res(201, s);
      }
      if (u === '/api/services/reorder') { var ids = b.ids; DB.services.sort(function (x, y) { return ids.indexOf(x.id) - ids.indexOf(y.id); }); return res(200, { ok: true }); }
      var sm = /^\\/api\\/services\\/(\\w+)$/.exec(u);
      if (sm) {
        var i = DB.services.findIndex(function (x) { return x.id === sm[1]; }); if (i < 0) return res(404, { error: 'not_found' });
        if (m === 'PUT') { var n = clone(b); n.id = DB.services[i].id; n.slug = DB.services[i].slug; DB.services[i] = n; return res(200, n); }
        if (m === 'DELETE') { DB.services.splice(i, 1); return res(200, { ok: true }); }
      }
      if (u === '/api/media' && m === 'GET') return res(200, media);
      if (u === '/api/media' && m === 'POST') { var nm = slug(String(b.name || 'image').replace(/\\.[^.]+$/, '')) + '-' + Date.now().toString(36); A['/uploads/' + nm] = b.dataUrl; var it = { name: nm, url: '/uploads/' + nm, size: 0, mtime: Date.now() }; media.unshift(it); return res(201, it); }
      var mm = /^\\/api\\/media\\/(.+)$/.exec(u);
      if (mm && m === 'DELETE') { media = media.filter(function (x) { return x.name !== decodeURIComponent(mm[1]); }); return res(200, { ok: true }); }
      if (u === '/api/password') return res(200, { ok: true });
      return res(404, { error: 'not_found' });
    }
  };
})();`;

function build(name, html, scripts, styles) {
  const inlineAssets = (txt) => txt.replace(/(["'(])(\/(?:uploads|assets)\/[\w.\-]+)/g, (m, q, p) => q + (assets[p] || p));
  // static asset references in the html shell (scripts keep path lookups through window.__A)
  let out = inlineAssets(html);
  out = out.replace(/<link rel="stylesheet" href="([^"]+)">/g, (m, href) => (styles[href] ? `<style>${inlineAssets(styles[href])}</style>` : m));
  out = out.replace(/<script src="([^"]+)"><\/script>/g, (m, src) => (scripts[src] != null ? `<script>${scripts[src].replace(/<\/script/gi, '<\\/script')}</script>` : m));
  out = out.replace('</title>', () => `</title><script>${mock.replace(/<\/script/gi, '<\\/script')}</script>`);
  fs.writeFileSync(path.join(OUT, name), out);
  console.log(name, (out.length / 1024).toFixed(0) + ' KB');
}

build('site.html', read('index.html'),
  { '/js/boot.js': read('js/boot.js'), '/js/site.js': jsify(read('js/site.js')) },
  { '/css/site.css': read('css/site.css') });
build('admin.html', read('admin/index.html'),
  { '/admin/admin.js': jsify(read('admin/admin.js')) },
  { '/admin/admin.css': read('admin/admin.css') });
