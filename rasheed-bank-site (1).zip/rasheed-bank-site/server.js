'use strict';
/**
 * Rasheed Bank website + admin panel server.
 * Zero dependencies: only Node.js built-ins (Node 18+).
 *
 *   npm start        -> http://localhost:3000        (site)
 *                       http://localhost:3000/admin  (admin panel)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const UPLOADS = process.env.UPLOADS_DIR ? path.resolve(process.env.UPLOADS_DIR) : path.join(PUBLIC, 'uploads');
const CONTENT_FILE = path.join(DATA_DIR, 'content.json');
const SEED_FILE = path.join(ROOT, 'data', 'content.json');
const AUTH_FILE = path.join(DATA_DIR, 'auth.json');
const IS_PROD = process.env.NODE_ENV === 'production';
const SESSION_MS = 8 * 60 * 60 * 1000;

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(CONTENT_FILE) && fs.existsSync(SEED_FILE)) fs.copyFileSync(SEED_FILE, CONTENT_FILE);

/* ------------------------------------------------------------------ storage */
function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJSON(file, obj) {
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, file);
}
let content = readJSON(CONTENT_FILE, { settings: {}, services: [] });
const save = () => writeJSON(CONTENT_FILE, content);

/* --------------------------------------------------------------------- auth */
const hashPw = (pw, salt) => crypto.scryptSync(String(pw), salt, 64).toString('hex');
function createAuth(user, pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return { user, salt, hash: hashPw(pw, salt) };
}
let auth = readJSON(AUTH_FILE, null);
if (!auth) {
  const user = process.env.ADMIN_USER || 'admin';
  // Default first-run password (override with ADMIN_PASSWORD, change later in the panel → Account)
  let pw = process.env.ADMIN_PASSWORD || 'iraq1122';
  const generated = !process.env.ADMIN_PASSWORD;
  auth = createAuth(user, pw);
  writeJSON(AUTH_FILE, auth);
  console.log('\n  ┌─ Admin account created ─────────────────────────────');
  console.log('  │ username : ' + user);
  console.log('  │ password : ' + (generated ? pw + '   (default – change it in the panel)' : '(from ADMIN_PASSWORD)'));
  console.log('  └──────────────────────────────────────────────────────\n');
}
const safeEq = (a, b) => {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const checkLogin = (user, pw) =>
  safeEq(String(user || ''), auth.user) && safeEq(hashPw(pw || '', auth.salt), auth.hash);

const sessions = new Map(); // token -> expiry
function newSession() {
  const t = crypto.randomBytes(32).toString('hex');
  sessions.set(t, Date.now() + SESSION_MS);
  return t;
}
function getSession(req) {
  const m = /(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie || '');
  if (!m) return null;
  const exp = sessions.get(m[1]);
  if (!exp || exp < Date.now()) { sessions.delete(m[1]); return null; }
  return m[1];
}
const failures = new Map(); // ip -> {n, reset}
function tooMany(ip) {
  const f = failures.get(ip);
  return f && f.reset > Date.now() && f.n >= 5;
}
function noteFail(ip) {
  const f = failures.get(ip);
  if (!f || f.reset < Date.now()) failures.set(ip, { n: 1, reset: Date.now() + 15 * 60 * 1000 });
  else f.n++;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of sessions) if (v < now) sessions.delete(k);
  for (const [k, v] of failures) if (v.reset < now) failures.delete(k);
}, 10 * 60 * 1000).unref();

/* --------------------------------------------------------------- validation */
// keys whose string values are URLs / colours / links and must match a strict pattern
const URL_KEYS = new Set(['image', 'logo', 'mapsUrl', 'mapEmbed', 'gallery', 'url']);
const COLOR_KEYS = new Set(['accent', 'accentLight', 'accentDeep', 'dark', 'paper', 'cream']);
const LINK_KEYS = new Set(['link']);
function okUrl(key, v) {
  if (v === '') return true;
  if (key === 'mapEmbed') return /^https:\/\/(www\.google\.com|maps\.google\.com)\/maps/.test(v);
  if (key === 'mapsUrl' || key === 'url') return /^https:\/\/[^\s]+$/.test(v);
  return /^\/uploads\/[\w.\-]+$/.test(v) || /^https:\/\/[^\s]+$/.test(v);
}
const okColor = (v) => v === '' || /^#[0-9a-fA-F]{6}$/.test(v);
// internal anchors (#about, #/service/x), site paths, https links, tel: and mailto:
const okLink = (v) => v === '' || /^(#[\w\-\/]*|\/[\w\-\/.]*|https:\/\/[^\s]+|tel:[\d+\-() ]+|mailto:[^\s]+)$/.test(v);
/** Deep-clean untrusted JSON: only plain data, bounded size, safe URLs. */
function clean(v, key = '', depth = 0) {
  if (depth > 6) return undefined;
  if (typeof v === 'string') {
    const s = v.replace(/\r\n/g, '\n').slice(0, 20000);
    if (URL_KEYS.has(key) && !okUrl(key, s.trim())) return '';
    if (COLOR_KEYS.has(key) && !okColor(s.trim())) return '';
    if (LINK_KEYS.has(key) && !okLink(s.trim())) return '';
    return URL_KEYS.has(key) || COLOR_KEYS.has(key) || LINK_KEYS.has(key) ? s.trim() : s;
  }
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'boolean') return v;
  if (Array.isArray(v)) return v.slice(0, 200).map((x) => clean(x, key, depth + 1)).filter((x) => x !== undefined);
  if (v && typeof v === 'object') {
    const o = {};
    for (const k of Object.keys(v).slice(0, 60)) {
      if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
      const c = clean(v[k], k, depth + 1);
      if (c !== undefined) o[k] = c;
    }
    return o;
  }
  return undefined;
}
const bil = (x) => ({ ar: String((x && x.ar) || ''), en: String((x && x.en) || '') });
function slugify(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}
function uniqueSlug(base, exceptId) {
  let slug = slugify(base) || 'service';
  let i = 2, cand = slug;
  while (content.services.some((s) => s.slug === cand && s.id !== exceptId)) cand = slug + '-' + i++;
  return cand;
}
function normService(input, existing) {
  const c = clean(input);
  const s = {
    id: existing ? existing.id : crypto.randomBytes(6).toString('hex'),
    slug: '',
    visible: c.visible !== false,
    name: bil(c.name),
    short: bil(c.short),
    details: bil(c.details),
    category: bil(c.category),
    image: typeof c.image === 'string' ? c.image : '',
    gallery: Array.isArray(c.gallery) ? c.gallery.filter((u) => typeof u === 'string' && u).slice(0, 24) : [],
  };
  if (!s.name.ar.trim() && !s.name.en.trim()) return { error: 'name_required' };
  s.slug = uniqueSlug(slugify(c.slug) || s.name.en || s.id, s.id);
  return { service: s };
}

/* ------------------------------------------------------------------- helpers */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
  '.woff2': 'font/woff2',
};
const COMPRESSIBLE = new Set(['.html', '.css', '.js', '.json', '.svg', '.txt']);
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':
    "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com; frame-src https://www.google.com https://maps.google.com; " +
    "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
};
function send(req, res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}
function sendJSON(req, res, status, obj, headers = {}) {
  send(req, res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
}
function readBody(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); }
      catch { reject(Object.assign(new Error('bad_json'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}
const clientIp = (req) => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || '';
const publicContent = () => ({ settings: content.settings, services: content.services.filter((s) => s.visible !== false) });

function serveStatic(req, res, urlPath) {
  let rel = decodeURIComponent(urlPath);
  if (rel.endsWith('/')) rel += 'index.html';
  let file = path.normalize(path.join(PUBLIC, rel));
  // user uploads may live outside /public when UPLOADS_DIR is set
  if (rel.startsWith('/uploads/')) file = path.normalize(path.join(UPLOADS, rel.slice('/uploads/'.length)));
  const base = rel.startsWith('/uploads/') ? UPLOADS : PUBLIC;
  if (!file.startsWith(base + path.sep) && file !== base) return send(req, res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(req, res, 404, 'Not found', { 'Content-Type': 'text/plain' });
    const ext = path.extname(file).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const headers = { 'Content-Type': type, 'Cache-Control': rel.startsWith('/uploads/') ? 'public, max-age=86400' : 'no-cache' };
    let data = fs.readFileSync(file);
    if (COMPRESSIBLE.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
      data = zlib.gzipSync(data); headers['Content-Encoding'] = 'gzip'; headers['Vary'] = 'Accept-Encoding';
    }
    send(req, res, 200, req.method === 'HEAD' ? '' : data, headers);
  });
}

/* ----------------------------------------------------------------------- API */
const IMG_SIGS = [
  { ext: '.png', test: (b) => b.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) },
  { ext: '.jpg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { ext: '.gif', test: (b) => b.slice(0, 4).toString('latin1') === 'GIF8' },
  { ext: '.webp', test: (b) => b.slice(0, 4).toString('latin1') === 'RIFF' && b.slice(8, 12).toString('latin1') === 'WEBP' },
];
const MEDIA_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg']);

async function handleApi(req, res, url) {
  const route = url.pathname.replace(/^\/api/, '');
  const method = req.method;

  if (route === '/content' && method === 'GET') return sendJSON(req, res, 200, publicContent());
  if (route === '/health') return sendJSON(req, res, 200, { ok: true });

  // CSRF defence for everything that changes state (plus SameSite=Strict cookie)
  if (method !== 'GET') {
    if (req.headers['x-requested-with'] !== 'XMLHttpRequest') return sendJSON(req, res, 403, { error: 'csrf' });
    const origin = req.headers.origin;
    if (origin) {
      let ok = false;
      try { ok = new URL(origin).host === req.headers.host; } catch { /* noop */ }
      if (!ok) return sendJSON(req, res, 403, { error: 'csrf' });
    }
  }

  if (route === '/login' && method === 'POST') {
    const ip = clientIp(req);
    if (tooMany(ip)) return sendJSON(req, res, 429, { error: 'too_many_attempts' });
    const b = await readBody(req, 10 * 1024);
    if (!checkLogin(b.username, b.password)) { noteFail(ip); return sendJSON(req, res, 401, { error: 'invalid_credentials' }); }
    failures.delete(ip);
    const token = newSession();
    const cookie = `sid=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}` +
      (IS_PROD || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '');
    return sendJSON(req, res, 200, { ok: true, user: auth.user }, { 'Set-Cookie': cookie });
  }
  if (route === '/logout' && method === 'POST') {
    const t = getSession(req); if (t) sessions.delete(t);
    return sendJSON(req, res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
  }

  // ---- everything below needs a session
  const token = getSession(req);
  if (route === '/me' && method === 'GET') return sendJSON(req, res, token ? 200 : 401, token ? { user: auth.user } : { error: 'unauthorized' });
  if (!token) return sendJSON(req, res, 401, { error: 'unauthorized' });

  if (route === '/admin/content' && method === 'GET') return sendJSON(req, res, 200, content);

  if (route === '/settings' && method === 'PUT') {
    const b = await readBody(req, 2 * 1024 * 1024);
    const c = clean(b);
    if (!c || typeof c !== 'object' || Array.isArray(c)) return sendJSON(req, res, 400, { error: 'invalid' });
    content.settings = c; save();
    return sendJSON(req, res, 200, { ok: true, settings: content.settings });
  }

  if (route === '/services' && method === 'POST') {
    const r = normService(await readBody(req, 2 * 1024 * 1024));
    if (r.error) return sendJSON(req, res, 400, { error: r.error });
    content.services.push(r.service); save();
    return sendJSON(req, res, 201, r.service);
  }
  if (route === '/services/reorder' && method === 'POST') {
    const b = await readBody(req, 64 * 1024);
    if (!Array.isArray(b.ids)) return sendJSON(req, res, 400, { error: 'invalid' });
    const byId = new Map(content.services.map((s) => [s.id, s]));
    const next = b.ids.map((id) => byId.get(id)).filter(Boolean);
    for (const s of content.services) if (!next.includes(s)) next.push(s);
    content.services = next; save();
    return sendJSON(req, res, 200, { ok: true });
  }
  const sm = /^\/services\/([a-f0-9]{12})$/.exec(route);
  if (sm) {
    const i = content.services.findIndex((s) => s.id === sm[1]);
    if (i < 0) return sendJSON(req, res, 404, { error: 'not_found' });
    if (method === 'PUT') {
      const r = normService(await readBody(req, 2 * 1024 * 1024), content.services[i]);
      if (r.error) return sendJSON(req, res, 400, { error: r.error });
      content.services[i] = r.service; save();
      return sendJSON(req, res, 200, r.service);
    }
    if (method === 'DELETE') { content.services.splice(i, 1); save(); return sendJSON(req, res, 200, { ok: true }); }
  }

  if (route === '/media' && method === 'GET') {
    const files = fs.readdirSync(UPLOADS).filter((f) => MEDIA_EXT.has(path.extname(f).toLowerCase())).map((f) => {
      const st = fs.statSync(path.join(UPLOADS, f));
      return { name: f, url: '/uploads/' + f, size: st.size, mtime: st.mtimeMs };
    }).sort((a, b) => b.mtime - a.mtime);
    return sendJSON(req, res, 200, files);
  }
  if (route === '/media' && method === 'POST') {
    const b = await readBody(req, 9 * 1024 * 1024);
    const m = /^data:image\/(png|jpeg|webp|gif);base64,([A-Za-z0-9+/=]+)$/.exec(String(b.dataUrl || ''));
    if (!m) return sendJSON(req, res, 400, { error: 'unsupported_image' });
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > 6 * 1024 * 1024) return sendJSON(req, res, 413, { error: 'too_large' });
    const sig = IMG_SIGS.find((s) => s.test(buf));
    if (!sig) return sendJSON(req, res, 400, { error: 'unsupported_image' });
    const base = slugify(String(b.name || '').replace(/\.[^.]+$/, '')) || 'image';
    const name = `${base}-${Date.now().toString(36)}${crypto.randomBytes(2).toString('hex')}${sig.ext}`;
    fs.writeFileSync(path.join(UPLOADS, name), buf);
    return sendJSON(req, res, 201, { name, url: '/uploads/' + name, size: buf.length });
  }
  const mm = /^\/media\/([\w.\-]+)$/.exec(route);
  if (mm && method === 'DELETE') {
    const file = path.join(UPLOADS, mm[1]);
    if (!file.startsWith(UPLOADS + path.sep) || !fs.existsSync(file)) return sendJSON(req, res, 404, { error: 'not_found' });
    if (JSON.stringify(content).includes('/uploads/' + mm[1])) return sendJSON(req, res, 409, { error: 'in_use' });
    fs.unlinkSync(file);
    return sendJSON(req, res, 200, { ok: true });
  }

  if (route === '/password' && method === 'POST') {
    const b = await readBody(req, 10 * 1024);
    if (!checkLogin(auth.user, b.current)) return sendJSON(req, res, 403, { error: 'invalid_credentials' });
    if (typeof b.next !== 'string' || b.next.length < 10) return sendJSON(req, res, 400, { error: 'weak_password' });
    auth = createAuth(auth.user, b.next); writeJSON(AUTH_FILE, auth);
    sessions.clear();
    const t = newSession();
    const cookie = `sid=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}` + (IS_PROD || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '');
    return sendJSON(req, res, 200, { ok: true }, { 'Set-Cookie': cookie });
  }

  return sendJSON(req, res, 404, { error: 'not_found' });
}

/* -------------------------------------------------------------------- server */
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(req, res, 405, 'Method not allowed');
    if (url.pathname === '/admin') return send(req, res, 301, '', { Location: '/admin/' });
    serveStatic(req, res, url.pathname);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    if (!res.headersSent) sendJSON(req, res, status, { error: status === 500 ? 'server_error' : e.message });
  }
});
server.listen(PORT, () => {
  console.log(`Rasheed Bank site  →  http://localhost:${PORT}`);
  console.log(`Admin panel        →  http://localhost:${PORT}/admin/`);
});
