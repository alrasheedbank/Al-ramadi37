/* Rasheed Bank – admin panel (vanilla JS, AR / EN interface). */
(() => {
  'use strict';

  /* ------------------------------------------------------------------ i18n */
  const L = {
    en: {
      title: 'Admin panel', loginSub: 'Sign in to manage the website', user: 'Username', pass: 'Password', signIn: 'Sign in',
      invalid: 'Wrong username or password.', tooMany: 'Too many attempts. Try again in 15 minutes.', logout: 'Sign out', viewSite: 'View website',
      dashboard: 'Dashboard', services: 'Services', slider: 'Home slider', appearance: 'Appearance', brand: 'Brand & footer', sections: 'Sections & menu', about: 'About page', contact: 'Contact & Location', labels: 'Texts & buttons', media: 'Media library', account: 'Account',
      save: 'Save changes', saved: 'Saved', unsaved: 'You have unsaved changes', allSaved: 'All changes saved', cancel: 'Cancel', delete: 'Delete', edit: 'Edit', add: 'Add', remove: 'Remove', hide: 'Hide', show: 'Show', hidden: 'Hidden', visible: 'Visible on the website',
      addService: 'Add service', newService: 'New service', editService: 'Edit service', name: 'Service name', short: 'Short description', details: 'Detailed description',
      detailsHelp: 'Shown on the service page. Leave an empty line between paragraphs. Start lines with "- " for a bullet list, or "## " for a sub-heading.',
      category: 'Category tag (optional)', categoryHelp: 'A small label such as “Accounts” or “Trade finance”, shown on the card and the service page.',
      image: 'Image', choose: 'Choose image', change: 'Change image', noImage: 'No image', gallery: 'Extra photos (optional)', galleryHelp: 'Shown as a photo grid on the service page. Click a photo on the website to enlarge it.', addPhotos: 'Add photos', openOnSite: 'Open on site',
      confirmDel: 'Delete this item? This cannot be undone.', moveUp: 'Move up', moveDown: 'Move down', nameReq: 'Please enter the service name in at least one language.',
      siteName: 'Bank name', tagline: 'Tagline', logo: 'Logo', footer: 'Footer text', seoDesc: 'Search-engine description', seoHelp: 'One or two sentences shown by Google under the site title.',
      social: 'Social links', socialHint: 'Shown in the website footer. Use the full https:// address.', socialName: 'Name (e.g. Facebook)', socialUrl: 'Address (https://…)', addSocial: 'Add link',
      slidesT: 'Slides', slidesHint: 'The photos that slide on the home page. The first slide is shown first.', slide: 'Slide', fTitle: 'Title', subtitle: 'Subtitle', addSlide: 'Add slide',
      focus: 'Photo focus', focusCenter: 'Center', focusTop: 'Top', focusBottom: 'Bottom', focusLeft: 'Left', focusRight: 'Right',
      heroPreview: 'Live preview', layoutShape: 'Slider shape & layout', layout: 'Layout', layoutSplit: 'Text + shaped photo (side by side)', layoutFull: 'Full-width photo behind the text',
      shape: 'Photo shape', shapeHelp: 'Used by the “Text + shaped photo” layout. The window arch matches the bank’s Islamic style.',
      shArch: 'Window arch', shPointed: 'Pointed arch', shRounded: 'Rounded', shCircle: 'Circle', shOval: 'Oval', shPill: 'Capsule', shLeaf: 'Leaf', shHex: 'Hexagon', shRect: 'Rectangle',
      size: 'Photo size', sizeS: 'Small', sizeM: 'Medium', sizeL: 'Large', ratio: 'Photo proportion', ratioPortrait: 'Portrait', ratioSquare: 'Square', ratioLandscape: 'Landscape',
      mediaSide: 'Photo position', sideEnd: 'Opposite the text start', sideStart: 'Before the text', heroHeight: 'Section height', hFull: 'Full screen', hTall: 'Tall', hMedium: 'Medium',
      motion: 'Motion & controls', effect: 'Transition effect', fxFade: 'Fade', fxZoom: 'Fade + slow zoom', fxSlide: 'Slide', autoplay: 'Play automatically', interval: 'Seconds per slide', seconds: 's',
      arrows: 'Previous / next arrows', dots: 'Progress bars', badge: '“Since 1988” badge', coins: 'Floating gold coins', scrollCue: '“Discover” scroll hint', overlay: 'Background darkness', overlayHelp: 'Higher = darker, text is easier to read.',
      buttonsT: 'Slider buttons', showButtons: 'Show the two buttons', btnPrimary: 'Main button', btnSecondary: 'Second button', btnLabel: 'Button text (empty = default)', btnLink: 'Link', btnLinkHelp: 'Use #services, #about, #location, or a full https:// address.',
      themeT: 'Colours & style', themeHint: 'Pick a ready colour theme or set each colour yourself. Changes apply to the whole website.', presets: 'Ready themes',
      presetGold: 'Classic gold', presetGreen: 'Deep green', presetNavy: 'Navy', presetBurgundy: 'Burgundy',
      cAccent: 'Gold', cAccentLight: 'Light gold', cAccentDeep: 'Deep gold (text accents)', cDark: 'Dark background', cPaper: 'Page background', cCream: 'Soft background',
      radius: 'Corner roundness', radiusHelp: '0 = square corners, 40 = very round.', resetTheme: 'Reset to classic gold',
      splashT: 'Opening animation', splashOn: 'Show the opening logo animation', splashText: 'Text under the logo (empty = “RASHEED BANK”)',
      sectionsT: 'Home page sections', sectionsHint: 'Choose which sections appear on the home page and in what order. The menu follows the same order.', menuLabels: 'Menu names', menuHint: 'Leave empty to use the default names.',
      secHome: 'Home', secAbout: 'About', secServices: 'Services', secLocation: 'Location', svcIntro: 'Services section heading',
      aboutText: 'About text', vision: 'Vision', mission: 'Mission', facts: 'Highlight numbers', factsHint: 'Use {years} for years of service and {services} for the number of services (calculated automatically). The first 4-digit value is used as the founding year.',
      fact: 'Item', value: 'Value', label: 'Label', addFact: 'Add item', aboutImage: 'About photo',
      locTitle: 'Section heading', address: 'Address', phone: 'Phone', email: 'Email', hours: 'Opening hours', mapsUrl: 'Google Maps link (button)', mapEmbed: 'Google Maps embed URL', mapQuery: 'Map search text',
      mapEmbedHelp: 'For an exact pin: Google Maps → Share → Embed a map → copy the src="…" address and paste it here. If empty, the search text below is used.',
      labelsHint: 'Every fixed word on the website (buttons, small headings). Leave a field empty to keep the default shown in grey.',
      upload: 'Upload images', drop: 'Drop images here or click to upload', uploading: 'Uploading…', inUse: 'This image is in use. Remove it from the content first.',
      copyUrl: 'Copy link', copied: 'Link copied', badImg: 'Unsupported image. Use JPG, PNG, WEBP or GIF.', select: 'Add selected',
      current: 'Current password', next: 'New password (min. 10 characters)', changePw: 'Change password', pwChanged: 'Password changed', pwBad: 'Wrong current password or the new one is too short.',
      statServices: 'Services', statVisible: 'Visible on site', statSlides: 'Slider photos', statMedia: 'Images',
      tips: 'Quick guide', tip1: 'Services → add, edit, reorder or hide services. Each one gets its own detail page.', tip2: 'Home slider → change the photo shape (window arch, circle, hexagon…), layout, effect and speed.',
      tip3: 'Appearance → colours, corner style and the opening animation. Sections & menu → order and visibility.', tip4: 'Every text has an Arabic and an English field – fill both.', tip5: 'Settings pages are saved with the “Save changes” bar; services save when you press Save in their window.',
      networkErr: 'Network error. Please try again.', sessionEnd: 'Your session ended. Please sign in again.', ar: 'Arabic', en: 'English', menu: 'Menu', preview: 'Preview mode – changes are not stored.',
    },
    ar: {
      title: 'لوحة التحكم', loginSub: 'سجّل الدخول لإدارة الموقع', user: 'اسم المستخدم', pass: 'كلمة المرور', signIn: 'دخول',
      invalid: 'اسم المستخدم أو كلمة المرور غير صحيحة.', tooMany: 'محاولات كثيرة. حاول مجدداً بعد 15 دقيقة.', logout: 'تسجيل الخروج', viewSite: 'عرض الموقع',
      dashboard: 'الرئيسية', services: 'الخدمات', slider: 'سلايدر الصفحة الرئيسية', appearance: 'المظهر', brand: 'الهوية وأسفل الموقع', sections: 'الأقسام والقائمة', about: 'صفحة من نحن', contact: 'التواصل والموقع', labels: 'النصوص والأزرار', media: 'مكتبة الصور', account: 'الحساب',
      save: 'حفظ التغييرات', saved: 'تم الحفظ', unsaved: 'لديك تغييرات غير محفوظة', allSaved: 'تم حفظ كل التغييرات', cancel: 'إلغاء', delete: 'حذف', edit: 'تعديل', add: 'إضافة', remove: 'إزالة', hide: 'إخفاء', show: 'إظهار', hidden: 'مخفية', visible: 'ظاهرة في الموقع',
      addService: 'إضافة خدمة', newService: 'خدمة جديدة', editService: 'تعديل الخدمة', name: 'اسم الخدمة', short: 'وصف مختصر', details: 'الوصف التفصيلي',
      detailsHelp: 'يظهر في صفحة الخدمة. اترك سطراً فارغاً بين الفقرات. ابدأ السطر بـ "- " لعمل قائمة نقطية، أو بـ "## " لعنوان فرعي.',
      category: 'وسم التصنيف (اختياري)', categoryHelp: 'تسمية صغيرة مثل «الحسابات» أو «التمويل التجاري» تظهر على البطاقة وصفحة الخدمة.',
      image: 'الصورة', choose: 'اختيار صورة', change: 'تغيير الصورة', noImage: 'لا توجد صورة', gallery: 'صور إضافية (اختياري)', galleryHelp: 'تظهر كشبكة صور في صفحة الخدمة، وتكبر عند الضغط عليها في الموقع.', addPhotos: 'إضافة صور', openOnSite: 'فتح في الموقع',
      confirmDel: 'هل تريد حذف هذا العنصر؟ لا يمكن التراجع.', moveUp: 'تحريك للأعلى', moveDown: 'تحريك للأسفل', nameReq: 'يرجى إدخال اسم الخدمة بلغة واحدة على الأقل.',
      siteName: 'اسم المصرف', tagline: 'الشعار النصي', logo: 'الشعار', footer: 'نص أسفل الموقع', seoDesc: 'وصف محركات البحث', seoHelp: 'جملة أو جملتان تظهران في نتائج جوجل تحت عنوان الموقع.',
      social: 'روابط التواصل الاجتماعي', socialHint: 'تظهر أسفل الموقع. استخدم العنوان الكامل https://', socialName: 'الاسم (مثل فيسبوك)', socialUrl: 'العنوان (https://…)', addSocial: 'إضافة رابط',
      slidesT: 'الشرائح', slidesHint: 'الصور التي تتحرك في الصفحة الرئيسية. تظهر الشريحة الأولى أولاً.', slide: 'شريحة', fTitle: 'العنوان', subtitle: 'العنوان الفرعي', addSlide: 'إضافة شريحة',
      focus: 'تركيز الصورة', focusCenter: 'الوسط', focusTop: 'الأعلى', focusBottom: 'الأسفل', focusLeft: 'اليسار', focusRight: 'اليمين',
      heroPreview: 'معاينة مباشرة', layoutShape: 'شكل السلايدر وتنسيقه', layout: 'التنسيق', layoutSplit: 'نص + صورة بشكل محدد (جنباً إلى جنب)', layoutFull: 'صورة بعرض الصفحة خلف النص',
      shape: 'شكل الصورة', shapeHelp: 'يُستخدم مع تنسيق «نص + صورة بشكل محدد». القوس (النافذة) ينسجم مع الطابع الإسلامي للمصرف.',
      shArch: 'قوس (نافذة)', shPointed: 'قوس مدبب', shRounded: 'زوايا دائرية', shCircle: 'دائرة', shOval: 'بيضاوي', shPill: 'كبسولة', shLeaf: 'ورقة', shHex: 'سداسي', shRect: 'مستطيل',
      size: 'حجم الصورة', sizeS: 'صغير', sizeM: 'متوسط', sizeL: 'كبير', ratio: 'نسبة الصورة', ratioPortrait: 'طولي', ratioSquare: 'مربع', ratioLandscape: 'عرضي',
      mediaSide: 'موضع الصورة', sideEnd: 'في الجهة المقابلة للنص', sideStart: 'قبل النص', heroHeight: 'ارتفاع القسم', hFull: 'ملء الشاشة', hTall: 'طويل', hMedium: 'متوسط',
      motion: 'الحركة وأدوات التحكم', effect: 'تأثير الانتقال', fxFade: 'تلاشي', fxZoom: 'تلاشي مع تقريب بطيء', fxSlide: 'انزلاق', autoplay: 'تشغيل تلقائي', interval: 'ثوانٍ لكل شريحة', seconds: 'ث',
      arrows: 'أسهم السابق / التالي', dots: 'أشرطة التقدم', badge: 'شارة «منذ 1988»', coins: 'العملات الذهبية الطافية', scrollCue: 'إشارة «اكتشف» للتمرير', overlay: 'عتمة الخلفية', overlayHelp: 'كلما زادت زادت العتمة وسهلت قراءة النص.',
      buttonsT: 'أزرار السلايدر', showButtons: 'إظهار الزرين', btnPrimary: 'الزر الرئيسي', btnSecondary: 'الزر الثاني', btnLabel: 'نص الزر (فارغ = الافتراضي)', btnLink: 'الرابط', btnLinkHelp: 'استخدم #services أو #about أو #location، أو عنواناً كاملاً https://',
      themeT: 'الألوان والمظهر', themeHint: 'اختر سمة جاهزة أو حدّد كل لون بنفسك. تنطبق التغييرات على الموقع كله.', presets: 'سمات جاهزة',
      presetGold: 'ذهبي كلاسيكي', presetGreen: 'أخضر داكن', presetNavy: 'كحلي', presetBurgundy: 'عنابي',
      cAccent: 'الذهبي', cAccentLight: 'الذهبي الفاتح', cAccentDeep: 'الذهبي الداكن (لمسات النص)', cDark: 'لون الخلفية الداكنة', cPaper: 'خلفية الصفحة', cCream: 'الخلفية الناعمة',
      radius: 'استدارة الزوايا', radiusHelp: '0 = زوايا حادة، 40 = دائرية جداً.', resetTheme: 'العودة إلى الذهبي الكلاسيكي',
      splashT: 'حركة الافتتاح', splashOn: 'إظهار حركة الشعار عند فتح الموقع', splashText: 'النص تحت الشعار (فارغ = «RASHEED BANK»)',
      sectionsT: 'أقسام الصفحة الرئيسية', sectionsHint: 'اختر الأقسام التي تظهر في الصفحة الرئيسية وترتيبها. تتبع القائمة الترتيب نفسه.', menuLabels: 'أسماء القائمة', menuHint: 'اتركها فارغة لاستخدام الأسماء الافتراضية.',
      secHome: 'الرئيسية', secAbout: 'من نحن', secServices: 'الخدمات', secLocation: 'الموقع', svcIntro: 'عنوان قسم الخدمات',
      aboutText: 'نص من نحن', vision: 'الرؤية', mission: 'الرسالة', facts: 'الأرقام البارزة', factsHint: 'استخدم {years} لعدد سنوات الخدمة و {services} لعدد الخدمات (يحسبان تلقائياً). أول قيمة من 4 أرقام تُعتمد كسنة التأسيس.',
      fact: 'عنصر', value: 'القيمة', label: 'التسمية', addFact: 'إضافة عنصر', aboutImage: 'صورة من نحن',
      locTitle: 'عنوان القسم', address: 'العنوان', phone: 'الهاتف', email: 'البريد الإلكتروني', hours: 'ساعات الدوام', mapsUrl: 'رابط خرائط جوجل (للزر)', mapEmbed: 'رابط تضمين الخريطة', mapQuery: 'نص البحث في الخريطة',
      mapEmbedHelp: 'لتحديد الموقع بدقة: خرائط جوجل ← مشاركة ← تضمين خريطة ← انسخ العنوان داخل src="…" والصقه هنا. إن تُرك فارغاً يُستخدم نص البحث أدناه.',
      labelsHint: 'كل كلمة ثابتة في الموقع (الأزرار والعناوين الصغيرة). اترك الحقل فارغاً للإبقاء على الافتراضي الظاهر بالرمادي.',
      upload: 'رفع صور', drop: 'اسحب الصور هنا أو اضغط للرفع', uploading: 'جارٍ الرفع…', inUse: 'هذه الصورة مستخدمة. أزلها من المحتوى أولاً.',
      copyUrl: 'نسخ الرابط', copied: 'تم نسخ الرابط', badImg: 'صورة غير مدعومة. استخدم JPG أو PNG أو WEBP أو GIF.', select: 'إضافة المحدد',
      current: 'كلمة المرور الحالية', next: 'كلمة المرور الجديدة (10 أحرف على الأقل)', changePw: 'تغيير كلمة المرور', pwChanged: 'تم تغيير كلمة المرور', pwBad: 'كلمة المرور الحالية خاطئة أو الجديدة قصيرة.',
      statServices: 'الخدمات', statVisible: 'الظاهرة في الموقع', statSlides: 'صور السلايدر', statMedia: 'الصور',
      tips: 'دليل سريع', tip1: 'الخدمات ← أضف الخدمات أو عدّلها أو أعد ترتيبها أو أخفها. لكل خدمة صفحة تفاصيل.', tip2: 'سلايدر الصفحة الرئيسية ← غيّر شكل الصورة (قوس، دائرة، سداسي…) والتنسيق والتأثير والسرعة.',
      tip3: 'المظهر ← الألوان وشكل الزوايا وحركة الافتتاح. الأقسام والقائمة ← الترتيب والإظهار.', tip4: 'لكل نص حقل بالعربية وآخر بالإنجليزية – املأ الاثنين.', tip5: 'صفحات الإعدادات تُحفظ بشريط «حفظ التغييرات»؛ أما الخدمات فتُحفظ بزر الحفظ في نافذتها.',
      networkErr: 'خطأ في الاتصال. حاول مرة أخرى.', sessionEnd: 'انتهت الجلسة. يرجى تسجيل الدخول مجدداً.', ar: 'العربية', en: 'English', menu: 'القائمة', preview: 'وضع المعاينة – لا يتم حفظ التغييرات.',
    },
  };
  let lang = 'ar';
  try { lang = localStorage.getItem('adminLang') === 'en' ? 'en' : 'ar'; } catch (e) { /* noop */ }
  const t = (k) => L[lang][k] || k;

  /* Default text of the website's fixed words (shown as grey placeholders on the "Texts & buttons" page) */
  const SITE_TEXT = {
    ourServices: { ar: 'خدماتنا', en: 'Our services' }, findUs: { ar: 'موقعنا', en: 'Find us' }, learn: { ar: 'معلومات أكثر', en: 'Learn more' }, back: { ar: 'العودة إلى الخدمات', en: 'Back to services' },
    other: { ar: 'خدمات أخرى', en: 'Other services' }, interested: { ar: 'هل تودّ الاستفسار؟', en: 'Have a question?' },
    visit: { ar: 'يسعد موظفونا بخدمتكم في الفرع. تفضّلوا بزيارتنا للحصول على التفاصيل والمستندات المطلوبة.', en: 'Our team is happy to help at the branch. Visit us for details and the documents you will need.' },
    vision: { ar: 'رؤيتنا', en: 'Our vision' }, mission: { ar: 'رسالتنا', en: 'Our mission' }, address: { ar: 'العنوان', en: 'Address' }, phone: { ar: 'الهاتف', en: 'Phone' }, email: { ar: 'البريد الإلكتروني', en: 'Email' },
    hours: { ar: 'ساعات الدوام', en: 'Opening hours' }, openMaps: { ar: 'افتح في خرائط جوجل', en: 'Open in Google Maps' }, quick: { ar: 'روابط سريعة', en: 'Quick links' }, contact: { ar: 'تواصل معنا', en: 'Contact' },
    scroll: { ar: 'اكتشف', en: 'Discover' }, est: { ar: 'منذ', en: 'Since' }, noServices: { ar: 'لا توجد خدمات لعرضها حالياً.', en: 'No services to show yet.' }, follow: { ar: 'تابعونا', en: 'Follow us' },
  };
  const MULTILINE_LABELS = new Set(['visit']);

  const SHAPE_LIST = ['arch', 'pointed', 'rounded', 'circle', 'oval', 'pill', 'leaf', 'hexagon', 'rect'];
  const SHAPE_KEY = { arch: 'shArch', pointed: 'shPointed', rounded: 'shRounded', circle: 'shCircle', oval: 'shOval', pill: 'shPill', leaf: 'shLeaf', hexagon: 'shHex', rect: 'shRect' };
  const SHAPE_CSS = {
    arch: 'border-radius:999px 999px 8px 8px', pointed: 'clip-path:url(#clip-pointed)', rounded: 'border-radius:16px', circle: 'border-radius:50%', oval: 'border-radius:50%',
    pill: 'border-radius:999px', leaf: 'border-radius:46% 6% 46% 6% / 36% 6% 36% 6%', hexagon: 'clip-path:polygon(50% 0,100% 25%,100% 75%,50% 100%,0 75%,0 25%)', rect: 'border-radius:3px',
  };
  const PRESETS = {
    presetGold: { accent: '#c9a24a', accentLight: '#e6cf94', accentDeep: '#a37c26', dark: '#2b1f0b', paper: '#fffbf2', cream: '#f7f0e1' },
    presetGreen: { accent: '#c9a24a', accentLight: '#e6cf94', accentDeep: '#a37c26', dark: '#0f2a22', paper: '#fbfaf5', cream: '#edf3ee' },
    presetNavy: { accent: '#c9a24a', accentLight: '#e6cf94', accentDeep: '#a37c26', dark: '#10233f', paper: '#fbfcfe', cream: '#edf1f7' },
    presetBurgundy: { accent: '#c9a24a', accentLight: '#e6cf94', accentDeep: '#a37c26', dark: '#3a1218', paper: '#fffaf8', cream: '#f6ecea' },
  };
  const DEFAULTS = {
    theme: { ...PRESETS.presetGold, radius: 22 },
    hero: {
      layout: 'split', shape: 'arch', size: 'm', ratio: 'portrait', mediaSide: 'end', height: 'full', effect: 'zoom', autoplay: true, interval: 6.5,
      arrows: true, dots: true, badge: true, coins: true, scrollCue: true, overlay: 0.9, showButtons: true,
      buttons: { primary: { label: { ar: '', en: '' }, link: '#services' }, secondary: { label: { ar: '', en: '' }, link: '#location' } }, slides: [],
    },
    nav: { home: { ar: '', en: '' }, about: { ar: '', en: '' }, services: { ar: '', en: '' }, location: { ar: '', en: '' } },
    splash: { enabled: true, text: { ar: '', en: '' } },
    seo: { description: { ar: '', en: '' } },
    social: [], labels: {},
  };

  /* --------------------------------------------------------------- helpers */
  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'html') e.innerHTML = v; // constants only
      else if (k === 'value') e.value = v;
      else if (k === 'checked') e.checked = !!v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) { if (kid == null || kid === false) continue; e.append(kid.nodeType ? kid : document.createTextNode(kid)); }
    return e;
  }
  const IC = {
    dash: '<path d="M3 12l9-8 9 8M5 10v10h14V10"/>', svc: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 14h8"/>', slider: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 12h8M10 9l-2 3 2 3M14 9l2 3-2 3"/>',
    appearance: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 000 18c1.5 0 2-1 1.4-2.2-.7-1.4.2-2.8 1.8-2.8H18a3 3 0 003-3A9 9 0 0012 3z"/>', brand: '<path d="M12 3l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.4 6.8 19.1l1-5.8L3.5 9.2l5.9-.9z"/>',
    sections: '<path d="M4 6h16M4 12h16M4 18h10"/>', about: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', contact: '<path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/>',
    labels: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>', media: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>', account: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',
    up: '<path d="M6 15l6-6 6 6"/>', down: '<path d="M6 9l6 6 6-6"/>', trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>', edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    plus: '<path d="M12 5v14M5 12h14"/>', out: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>', menu: '<path d="M4 7h16M4 12h16M4 17h16"/>', ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v6H4V6h6"/>',
  };
  const ico = (n, s = 18) => h('span', { html: `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n] || ''}</svg>`, style: 'display:inline-flex' });
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const safeImg = (u) => (/^(\/uploads\/[\w.\-]+|https:\/\/[^\s]+|data:image\/)/.test(u || '') ? u : '');
  const cssUrl = (u) => (safeImg(u) ? `url("${safeImg(u)}")` : 'none');
  const get = (o, p) => p.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  function set(o, p, v) {
    const ks = p.split('.'); let c = o;
    ks.slice(0, -1).forEach((k) => { if (c[k] == null || typeof c[k] !== 'object') c[k] = {}; c = c[k]; });
    c[ks[ks.length - 1]] = v;
  }
  /** copy missing keys from defaults (objects recursively; arrays/scalars only when absent) */
  function fill(target, def) {
    for (const [k, v] of Object.entries(def)) {
      if (target[k] === undefined || target[k] === null) target[k] = clone(v);
      else if (v && typeof v === 'object' && !Array.isArray(v) && typeof target[k] === 'object') fill(target[k], v);
    }
    return target;
  }
  function toast(msg, kind) {
    const n = h('div', { class: 'toast ' + (kind || '') }, msg);
    document.getElementById('toasts').append(n);
    setTimeout(() => n.remove(), 3200);
  }
  async function api(method, url, body) {
    let r;
    try {
      r = await fetch(url, { method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }, body: body === undefined ? undefined : JSON.stringify(body) });
    } catch (e) { throw Object.assign(new Error('network'), { code: 'network' }); }
    let data = null; try { data = await r.json(); } catch (e) { /* empty */ }
    if (r.status === 401 && url !== '/api/login' && url !== '/api/me') { state.user = null; toast(t('sessionEnd'), 'err'); render(); throw Object.assign(new Error('unauthorized'), { code: 'unauthorized' }); }
    if (!r.ok) throw Object.assign(new Error((data && data.error) || 'error'), { code: (data && data.error) || 'error', status: r.status });
    return data;
  }
  const failMsg = (e) => (e.code === 'network' ? t('networkErr') : e.code === 'in_use' ? t('inUse') : e.code === 'unsupported_image' ? t('badImg') : e.code === 'name_required' ? t('nameReq') : e.message);

  /* ----------------------------------------------------------------- state */
  const state = { user: null, tab: 'dashboard', content: null, draft: null, dirty: false, media: [], navOpen: false };
  const root = document.getElementById('root');
  const noop = () => {};

  /* ------------------------------------------------------------ form fields */
  const markDirty = () => {
    state.dirty = true;
    const s = document.querySelector('.savebar .state'); if (s) { s.textContent = t('unsaved'); s.classList.add('dirty'); }
    const p = document.querySelector('.dirty-pill'); if (p) p.hidden = false;
  };
  const after = (cb) => () => { markDirty(); (cb || noop)(); };

  function textField(obj, path, label, o = {}) {
    const inp = o.multiline ? h('textarea', { rows: o.rows || 4 }) : h('input', { type: o.type || 'text', list: o.list || null });
    inp.value = get(obj, path) == null ? '' : get(obj, path);
    if (o.dir) inp.className = o.dir === 'rtl' ? 'ar-in' : 'en-in';
    if (o.ph) inp.placeholder = o.ph;
    inp.addEventListener('input', () => { set(obj, path, inp.value); after(o.onChange)(); });
    return h('div', { class: 'field' }, h('label', {}, label), inp, o.help && h('div', { class: 'help' }, o.help));
  }
  /** bilingual field: Arabic + English side by side */
  function bil(obj, path, label, o = {}) {
    const mk = (code) => {
      const inp = o.multiline ? h('textarea', { rows: o.rows || 4 }) : h('input', { type: 'text' });
      inp.value = get(obj, path + '.' + code) || '';
      inp.className = code === 'ar' ? 'ar-in' : 'en-in';
      inp.setAttribute('lang', code);
      if (o.ph && o.ph[code]) inp.placeholder = o.ph[code];
      inp.addEventListener('input', () => { set(obj, path + '.' + code, inp.value); (o.onInput || after(o.onChange))(); });
      return h('div', { class: 'field', style: 'margin:0' }, h('label', {}, t(code), h('span', { class: 'tag' }, code.toUpperCase())), inp);
    };
    return h('div', { class: 'field' }, label && h('label', {}, label), h('div', { class: 'grid2' }, mk('ar'), mk('en')), o.help && h('div', { class: 'help' }, o.help));
  }
  function selectField(obj, path, label, options, onChange, help) {
    const sel = h('select', {}, options.map(([v, l]) => h('option', { value: v }, l)));
    sel.value = get(obj, path); if (sel.value !== String(get(obj, path))) sel.selectedIndex = 0;
    sel.addEventListener('change', () => { set(obj, path, sel.value); after(onChange)(); });
    return h('div', { class: 'field' }, h('label', {}, label), sel, help && h('div', { class: 'help' }, help));
  }
  function toggleField(obj, path, label, onChange) {
    const cb = h('input', { type: 'checkbox', checked: get(obj, path) !== false });
    cb.addEventListener('change', () => { set(obj, path, cb.checked); after(onChange)(); });
    return h('div', { class: 'field' }, h('label', { class: 'switch' }, cb, label));
  }
  function rangeField(obj, path, label, min, max, step, unit, onChange, help) {
    const val = h('b', { class: 'range-val' });
    const inp = h('input', { type: 'range', min, max, step });
    const cur = Number(get(obj, path)); inp.value = Number.isFinite(cur) ? cur : min; val.textContent = inp.value + (unit || '');
    inp.addEventListener('input', () => { set(obj, path, Number(inp.value)); val.textContent = inp.value + (unit || ''); after(onChange)(); });
    return h('div', { class: 'field' }, h('label', {}, label, ' ', val), inp, help && h('div', { class: 'help' }, help));
  }
  function colorField(obj, path, label, onChange) {
    const col = h('input', { type: 'color' }); const hex = h('input', { type: 'text', maxlength: '7', class: 'en-in hex' });
    const init = get(obj, path) || '#000000'; col.value = init; hex.value = init;
    const apply = (v) => { set(obj, path, v); after(onChange)(); };
    col.addEventListener('input', () => { hex.value = col.value; apply(col.value); });
    hex.addEventListener('input', () => { if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) { col.value = hex.value; apply(hex.value); } });
    return h('div', { class: 'field' }, h('label', {}, label), h('div', { class: 'colorf' }, col, hex));
  }
  function imageField(obj, path, label, onChange) {
    const th = h('div', { class: 'thumb' });
    const draw = () => { const v = get(obj, path); th.className = 'thumb' + (v ? ' has' : ''); th.style.backgroundImage = cssUrl(v); th.textContent = v ? '' : t('noImage'); };
    draw();
    const fire = onChange || markDirty;
    const pick = () => openPicker((u) => { set(obj, path, u); draw(); fire(); btn.textContent = t('change'); clear.hidden = false; });
    const btn = h('button', { type: 'button', class: 'btn btn-line btn-sm', onclick: pick }, get(obj, path) ? t('change') : t('choose'));
    const clear = h('button', { type: 'button', class: 'btn btn-danger btn-sm', onclick: () => { set(obj, path, ''); draw(); fire(); btn.textContent = t('choose'); clear.hidden = true; } }, t('remove'));
    clear.hidden = !get(obj, path);
    return h('div', { class: 'field' }, label && h('label', {}, label), h('div', { class: 'imgf' }, th, btn, clear));
  }
  /** editable ordered list of sub-objects */
  function listEditor(arr, itemLabel, renderItem, blank, addLabel, onChange) {
    const box = h('div', { class: 'items' });
    const wrap = h('div', {}, box);
    const changed = () => { markDirty(); (onChange || noop)(); };
    const redraw = () => {
      box.replaceChildren(...arr.map((it, i) => h('div', { class: 'item' },
        h('div', { class: 'item-head' }, h('b', {}, itemLabel + ' ' + (i + 1)),
          h('div', { class: 'item-tools' },
            h('button', { type: 'button', class: 'icon-btn', title: t('moveUp'), disabled: i === 0, onclick: () => { [arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]; changed(); redraw(); } }, ico('up', 16)),
            h('button', { type: 'button', class: 'icon-btn', title: t('moveDown'), disabled: i === arr.length - 1, onclick: () => { [arr[i + 1], arr[i]] = [arr[i], arr[i + 1]]; changed(); redraw(); } }, ico('down', 16)),
            h('button', { type: 'button', class: 'icon-btn', title: t('remove'), onclick: () => { if (confirm(t('confirmDel'))) { arr.splice(i, 1); changed(); redraw(); } } }, ico('trash', 16)))),
        renderItem(it, i))));
    };
    redraw();
    wrap.append(h('button', { type: 'button', class: 'btn btn-line', style: 'margin-top:14px', onclick: () => { arr.push(clone(blank)); changed(); redraw(); } }, ico('plus', 16), addLabel));
    return wrap;
  }

  /* ----------------------------------------------------------- media picker */
  async function loadMedia() { state.media = await api('GET', '/api/media'); }
  function fileToDataUrl(file) {
    return new Promise((res, rej) => {
      if (!/^image\/(png|jpeg|webp|gif)$/.test(file.type)) return rej(Object.assign(new Error('unsupported_image'), { code: 'unsupported_image' }));
      const fr = new FileReader();
      fr.onerror = () => rej(new Error('read'));
      fr.onload = () => {
        if (file.type === 'image/gif') return res(fr.result);
        const img = new Image();
        img.onerror = () => rej(Object.assign(new Error('unsupported_image'), { code: 'unsupported_image' }));
        img.onload = () => {
          const MAX = 1800; const sc = Math.min(1, MAX / Math.max(img.width, img.height));
          if (sc === 1 && file.size < 1.5 * 1024 * 1024) return res(fr.result);
          const c = document.createElement('canvas'); c.width = Math.round(img.width * sc); c.height = Math.round(img.height * sc);
          const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0, c.width, c.height);
          res(file.type === 'image/png' ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.86));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  async function uploadFiles(files) {
    const out = [];
    for (const f of files) {
      try { const dataUrl = await fileToDataUrl(f); out.push(await api('POST', '/api/media', { name: f.name, dataUrl })); }
      catch (e) { if (e.code !== 'unauthorized') toast(f.name + ': ' + failMsg(e), 'err'); }
    }
    return out;
  }
  function dropzone(onDone) {
    const input = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/gif', multiple: true, hidden: true });
    const msg = h('div', {}, t('drop'));
    const z = h('div', { class: 'drop', tabindex: '0', role: 'button' }, ico('media', 26), msg, input);
    const run = async (files) => { msg.textContent = t('uploading'); const r = await uploadFiles([...files]); msg.textContent = t('drop'); if (r.length) { await loadMedia(); onDone(r); } };
    z.addEventListener('click', () => input.click());
    z.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
    input.addEventListener('change', () => run(input.files));
    z.addEventListener('dragover', (e) => { e.preventDefault(); z.classList.add('over'); });
    z.addEventListener('dragleave', () => z.classList.remove('over'));
    z.addEventListener('drop', (e) => { e.preventDefault(); z.classList.remove('over'); run(e.dataTransfer.files); });
    return z;
  }
  function modal(title, body, foot) {
    const close = () => { ov.remove(); document.removeEventListener('keydown', esc); };
    const esc = (e) => { if (e.key === 'Escape') close(); };
    const ov = h('div', { class: 'overlay', onclick: (e) => { if (e.target === ov) close(); } },
      h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
        h('div', { class: 'modal-head' }, h('h2', {}, title), h('button', { class: 'icon-btn', onclick: close, 'aria-label': t('cancel') }, '×')),
        h('div', { class: 'modal-body' }, body), foot && h('div', { class: 'modal-foot' }, foot(close))));
    document.addEventListener('keydown', esc);
    document.body.append(ov);
    return close;
  }
  /** opts.multiple → onPick receives an array of urls, otherwise a single url */
  async function openPicker(onPick, opts = {}) {
    try { await loadMedia(); } catch (e) { return; }
    const sel = new Set(); let close;
    const grid = h('div', { class: 'media-grid' });
    const draw = () => grid.replaceChildren(...state.media.map((m) => h('button', {
      type: 'button', class: 'm pick' + (sel.has(m.url) ? ' sel' : ''),
      onclick: () => { if (!opts.multiple) { onPick(m.url); close(); return; } if (sel.has(m.url)) sel.delete(m.url); else sel.add(m.url); draw(); },
    }, h('div', { class: 'pic', style: `background-image:${cssUrl(m.url)}` }), h('div', { class: 'meta' }, m.name))));
    draw();
    const zone = dropzone((r) => { if (!opts.multiple) { if (r.length === 1) { onPick(r[0].url); close(); return; } } else r.forEach((x) => sel.add(x.url)); draw(); });
    close = modal(t('choose'), h('div', {}, zone, grid), opts.multiple ? (cl) => [h('button', { class: 'btn btn-line', onclick: cl }, t('cancel')), h('button', { class: 'btn btn-primary', onclick: () => { onPick([...sel]); cl(); } }, t('select'))] : null);
  }

  /* ------------------------------------------------------------------- views */
  function viewDashboard() {
    const c = state.content; const s = c.settings;
    return h('div', {},
      h('div', { class: 'stats' },
        [[t('statServices'), c.services.length], [t('statVisible'), c.services.filter((x) => x.visible !== false).length], [t('statSlides'), ((s.hero || {}).slides || []).length], [t('statMedia'), state.media.length]]
          .map(([l, n]) => h('div', { class: 'stat' }, h('b', {}, String(n)), h('span', {}, l)))),
      h('div', { class: 'card' }, h('h2', {}, t('tips')), h('ul', { class: 'tips' }, ['tip1', 'tip2', 'tip3', 'tip4', 'tip5'].map((k) => h('li', {}, t(k))))));
  }

  /* services */
  const blankService = () => ({ name: { ar: '', en: '' }, short: { ar: '', en: '' }, details: { ar: '', en: '' }, category: { ar: '', en: '' }, image: '', gallery: [], visible: true });
  function galleryField(sv) {
    const box = h('div', { class: 'gal' });
    const draw = () => box.replaceChildren(
      ...sv.gallery.map((u, i) => h('div', { class: 'gal-i', style: `background-image:${cssUrl(u)}` }, h('button', { type: 'button', class: 'icon-btn', title: t('remove'), onclick: () => { sv.gallery.splice(i, 1); draw(); } }, '×'))),
      h('button', { type: 'button', class: 'gal-add', onclick: () => openPicker((urls) => { urls.forEach((u) => { if (!sv.gallery.includes(u)) sv.gallery.push(u); }); draw(); }, { multiple: true }) }, ico('plus', 20), t('addPhotos')));
    draw();
    return h('div', { class: 'field' }, h('label', {}, t('gallery')), box, h('div', { class: 'help' }, t('galleryHelp')));
  }
  function openServiceEditor(existing) {
    const sv = fill(existing ? clone(existing) : blankService(), blankService());
    const body = h('div', {},
      bil(sv, 'name', t('name'), { onInput: noop }),
      bil(sv, 'category', t('category'), { onInput: noop, help: t('categoryHelp') }),
      bil(sv, 'short', t('short'), { multiline: true, rows: 2, onInput: noop }),
      bil(sv, 'details', t('details'), { multiline: true, rows: 10, help: t('detailsHelp'), onInput: noop }),
      imageField(sv, 'image', t('image'), noop),
      galleryField(sv),
      h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: sv.visible !== false, onchange: (e) => { sv.visible = e.target.checked; } }), t('visible')));
    modal(existing ? t('editService') : t('newService'), body, (close) => [
      h('button', { class: 'btn btn-line', onclick: close }, t('cancel')),
      h('button', { class: 'btn btn-primary', onclick: async (e) => {
        if (!sv.name.ar.trim() && !sv.name.en.trim()) { toast(t('nameReq'), 'err'); return; }
        e.target.disabled = true;
        try {
          if (existing) { const r = await api('PUT', '/api/services/' + existing.id, sv); state.content.services[state.content.services.findIndex((x) => x.id === existing.id)] = r; }
          else state.content.services.push(await api('POST', '/api/services', sv));
          toast(t('saved'), 'ok'); close(); render();
        } catch (er) { e.target.disabled = false; if (er.code !== 'unauthorized') toast(failMsg(er), 'err'); }
      } }, t('save'))]);
  }
  function viewServices() {
    const list = state.content.services;
    const move = async (i, d) => {
      const j = i + d; if (j < 0 || j >= list.length) return;
      [list[i], list[j]] = [list[j], list[i]];
      try { await api('POST', '/api/services/reorder', { ids: list.map((x) => x.id) }); render(); } catch (e) { if (e.code !== 'unauthorized') toast(failMsg(e), 'err'); }
    };
    const del = async (sv) => {
      if (!confirm(t('confirmDel') + '\n\n' + (sv.name[lang] || sv.name.ar || sv.name.en))) return;
      try { await api('DELETE', '/api/services/' + sv.id); state.content.services = list.filter((x) => x.id !== sv.id); toast(t('saved'), 'ok'); render(); } catch (e) { if (e.code !== 'unauthorized') toast(failMsg(e), 'err'); }
    };
    const toggle = async (sv) => {
      try { const r = await api('PUT', '/api/services/' + sv.id, { ...sv, visible: sv.visible === false }); Object.assign(sv, r); render(); } catch (e) { if (e.code !== 'unauthorized') toast(failMsg(e), 'err'); }
    };
    return h('div', {}, list.map((sv, i) => h('div', { class: 'svc' },
      h('div', { class: 't', style: `background-image:${cssUrl(sv.image)}` }),
      h('div', { class: 'names' }, h('b', {}, sv.name[lang] || sv.name.ar || sv.name.en), h('span', {}, sv.name[lang === 'ar' ? 'en' : 'ar']), sv.visible === false && h('div', { class: 'off' }, t('hidden'))),
      h('div', { class: 'tools' },
        h('button', { class: 'icon-btn', title: t('moveUp'), disabled: i === 0, onclick: () => move(i, -1) }, ico('up', 16)),
        h('button', { class: 'icon-btn', title: t('moveDown'), disabled: i === list.length - 1, onclick: () => move(i, 1) }, ico('down', 16)),
        h('button', { class: 'btn btn-line btn-sm', onclick: () => toggle(sv) }, sv.visible === false ? t('show') : t('hide')),
        !window.__PREVIEW__ && sv.visible !== false && h('a', { class: 'btn btn-line btn-sm', href: '/#/service/' + encodeURIComponent(sv.slug), target: '_blank', rel: 'noopener' }, ico('ext', 14), t('openOnSite')),
        h('button', { class: 'btn btn-dark btn-sm', onclick: () => openServiceEditor(sv) }, ico('edit', 14), t('edit')),
        h('button', { class: 'btn btn-danger btn-sm', onclick: () => del(sv) }, ico('trash', 14), t('delete'))))));
  }

  /* settings pages (the draft is kept while you move between pages, saved with the save bar) */
  function settingsPage(build) {
    const d = state.draft;
    const bar = h('div', { class: 'savebar' },
      h('span', { class: 'state' + (state.dirty ? ' dirty' : '') }, state.dirty ? t('unsaved') : t('allSaved')),
      h('button', { class: 'btn btn-primary', onclick: async (e) => {
        e.target.disabled = true;
        try {
          const r = await api('PUT', '/api/settings', d);
          state.content.settings = r.settings; state.draft = fill(clone(r.settings), DEFAULTS); state.dirty = false; toast(t('saved'), 'ok'); render();
        } catch (er) { e.target.disabled = false; if (er.code !== 'unauthorized') toast(failMsg(er), 'err'); }
      } }, t('save')));
    return h('div', {}, build(d), bar);
  }

  /* ---- Home slider ---- */
  function shapeTile(id, w, hh) { return h('i', { style: `width:${w}px;height:${hh}px;${SHAPE_CSS[id]}` }); }
  function shapePicker(obj, path, onChange) {
    const wrap = h('div', { class: 'shapes', role: 'radiogroup', 'aria-label': t('shape') });
    const dims = { circle: [50, 50], hexagon: [52, 58], pill: [40, 58], oval: [46, 58] };
    const draw = () => wrap.replaceChildren(...SHAPE_LIST.map((id) => {
      const on = get(obj, path) === id; const [w, hh] = dims[id] || [46, 58];
      return h('button', { type: 'button', class: 'shape' + (on ? ' on' : ''), role: 'radio', 'aria-checked': String(on), onclick: () => { set(obj, path, id); after(onChange)(); draw(); } }, shapeTile(id, w, hh), h('span', {}, t(SHAPE_KEY[id])));
    }));
    draw();
    return h('div', { class: 'field' }, h('label', {}, t('shape')), wrap, h('div', { class: 'help' }, t('shapeHelp')));
  }
  function heroPreview(d) {
    const node = h('div', { class: 'hp' });
    const update = () => {
      const hc = d.hero; const first = (hc.slides || []).find((s) => s && s.image) || {};
      const full = hc.layout === 'full';
      const widths = { s: 36, m: 44, l: 54 };
      const ratio = hc.shape === 'circle' ? '1 / 1' : hc.shape === 'hexagon' ? '1 / 1.12' : ({ portrait: '4 / 5', square: '1 / 1', landscape: '5 / 4' })[hc.ratio] || '4 / 5';
      node.className = 'hp' + (full ? ' full' : '') + (hc.mediaSide === 'start' ? ' rev' : '');
      node.style.setProperty('--ov', String(hc.overlay || 0.9));
      node.style.setProperty('--dark', (d.theme && d.theme.dark) || '#2b1f0b');
      node.replaceChildren(...[
        full ? h('div', { class: 'bg', style: `background-image:${cssUrl(first.image)}` }) : null,
        full ? h('div', { class: 'veil' }) : null,
        h('div', { class: 'txt' }, h('u', { style: 'width:34%' }), h('u', { class: 'big', style: 'width:78%' }), h('u', { class: 'big', style: 'width:56%' }), h('u', { style: 'width:70%' }),
          hc.showButtons !== false && h('div', { class: 'btns' }, h('s', {}), h('s', { class: 'g' }))),
        full ? null : h('div', { class: 'shp', style: `width:${widths[hc.size] || 44}%;aspect-ratio:${ratio};${SHAPE_CSS[hc.shape] || SHAPE_CSS.arch};background-image:${cssUrl(first.image)}` })].filter(Boolean));
    };
    update();
    return { node, update };
  }
  function viewSlider() {
    return settingsPage((d) => {
      const hc = d.hero; hc.slides = hc.slides || [];
      const pv = heroPreview(d); const up = pv.update;
      return h('div', {},
        h('div', { class: 'card' }, h('h2', {}, t('heroPreview')), pv.node),
        h('div', { class: 'card' }, h('h2', {}, t('layoutShape')),
          selectField(hc, 'layout', t('layout'), [['split', t('layoutSplit')], ['full', t('layoutFull')]], up),
          shapePicker(hc, 'shape', up),
          h('div', { class: 'grid2' },
            selectField(hc, 'size', t('size'), [['s', t('sizeS')], ['m', t('sizeM')], ['l', t('sizeL')]], up),
            selectField(hc, 'ratio', t('ratio'), [['portrait', t('ratioPortrait')], ['square', t('ratioSquare')], ['landscape', t('ratioLandscape')]], up),
            selectField(hc, 'mediaSide', t('mediaSide'), [['end', t('sideEnd')], ['start', t('sideStart')]], up),
            selectField(hc, 'height', t('heroHeight'), [['full', t('hFull')], ['tall', t('hTall')], ['medium', t('hMedium')]], up)),
          rangeField(hc, 'overlay', t('overlay'), 0.3, 0.97, 0.01, '', up, t('overlayHelp'))),
        h('div', { class: 'card' }, h('h2', {}, t('motion')),
          h('div', { class: 'grid2' },
            selectField(hc, 'effect', t('effect'), [['zoom', t('fxZoom')], ['fade', t('fxFade')], ['slide', t('fxSlide')]]),
            rangeField(hc, 'interval', t('interval'), 3, 20, 0.5, ' ' + t('seconds'))),
          h('div', { class: 'checks' },
            toggleField(hc, 'autoplay', t('autoplay')), toggleField(hc, 'arrows', t('arrows')), toggleField(hc, 'dots', t('dots')),
            toggleField(hc, 'badge', t('badge')), toggleField(hc, 'coins', t('coins')), toggleField(hc, 'scrollCue', t('scrollCue')))),
        h('div', { class: 'card' }, h('h2', {}, t('buttonsT')),
          toggleField(hc, 'showButtons', t('showButtons'), up),
          h('datalist', { id: 'links' }, ['#services', '#about', '#location', '#home'].map((v) => h('option', { value: v }))),
          h('div', { class: 'grid2' },
            h('div', {}, h('h3', { class: 'sub' }, t('btnPrimary')), bil(hc, 'buttons.primary.label', t('btnLabel'), { ph: { ar: 'خدماتنا', en: 'Our services' } }), textField(hc, 'buttons.primary.link', t('btnLink'), { dir: 'ltr', list: 'links', help: t('btnLinkHelp') })),
            h('div', {}, h('h3', { class: 'sub' }, t('btnSecondary')), bil(hc, 'buttons.secondary.label', t('btnLabel'), { ph: { ar: 'موقعنا', en: 'Find us' } }), textField(hc, 'buttons.secondary.link', t('btnLink'), { dir: 'ltr', list: 'links' })))),
        h('div', { class: 'card' }, h('h2', {}, t('slidesT')), h('div', { class: 'hint' }, t('slidesHint')),
          listEditor(hc.slides, t('slide'), (sl) => h('div', {},
            imageField(sl, 'image', t('image'), after(up)),
            selectField(sl, 'position', t('focus'), [['center', t('focusCenter')], ['top', t('focusTop')], ['bottom', t('focusBottom')], ['left', t('focusLeft')], ['right', t('focusRight')]]),
            bil(sl, 'title', t('fTitle')), bil(sl, 'subtitle', t('subtitle'), { multiline: true, rows: 2 })),
          { image: '', position: 'center', title: { ar: '', en: '' }, subtitle: { ar: '', en: '' } }, t('addSlide'), up)));
    });
  }

  /* ---- Appearance ---- */
  function viewAppearance() {
    return settingsPage((d) => {
      const th = d.theme;
      const prev = h('div', { class: 'tp' });
      const up = () => {
        prev.style.setProperty('--a', th.accent); prev.style.setProperty('--a2', th.accentLight); prev.style.setProperty('--a3', th.accentDeep);
        prev.style.setProperty('--dk', th.dark); prev.style.setProperty('--pp', th.paper); prev.style.setProperty('--cr', th.cream); prev.style.setProperty('--r', (Number(th.radius) || 0) + 'px');
      };
      prev.append(h('div', { class: 'tp-top' }, h('b', {}, 'RASHEED BANK'), h('span', {})), h('div', { class: 'tp-body' }, h('div', { class: 'tp-card' }, h('i', {}), h('p', {}), h('p', { class: 's' }), h('em', {})), h('div', { class: 'tp-card' }, h('i', {}), h('p', {}), h('p', { class: 's' }), h('em', {}))));
      up();
      const colorsBox = h('div', { class: 'grid2' });
      const buildColors = () => colorsBox.replaceChildren(...[['accent', 'cAccent'], ['accentLight', 'cAccentLight'], ['accentDeep', 'cAccentDeep'], ['dark', 'cDark'], ['paper', 'cPaper'], ['cream', 'cCream']].map(([k, l]) => colorField(th, k, t(l), up)));
      buildColors();
      const presetBtns = Object.keys(PRESETS).map((k) => h('button', { type: 'button', class: 'preset', onclick: () => { Object.assign(th, PRESETS[k]); markDirty(); up(); buildColors(); } },
        h('span', { class: 'sw' }, h('i', { style: `background:${PRESETS[k].dark}` }), h('i', { style: `background:${PRESETS[k].accent}` }), h('i', { style: `background:${PRESETS[k].cream}` })), t(k)));
      return h('div', {},
        h('div', { class: 'card' }, h('h2', {}, t('themeT')), h('div', { class: 'hint' }, t('themeHint')), prev,
          h('div', { class: 'field', style: 'margin-top:16px' }, h('label', {}, t('presets')), h('div', { class: 'presets' }, presetBtns)),
          colorsBox,
          rangeField(th, 'radius', t('radius'), 0, 40, 1, ' px', up, t('radiusHelp')),
          h('button', { type: 'button', class: 'btn btn-line btn-sm', onclick: () => { Object.assign(th, clone(DEFAULTS.theme)); markDirty(); up(); buildColors(); } }, t('resetTheme'))),
        h('div', { class: 'card' }, h('h2', {}, t('splashT')), toggleField(d, 'splash.enabled', t('splashOn')), bil(d, 'splash.text', t('splashText'), { ph: { ar: 'RASHEED BANK', en: 'RASHEED BANK' } })));
    });
  }

  /* ---- Brand & footer ---- */
  function viewBrand() {
    return settingsPage((d) => {
      d.site = d.site || {};
      return h('div', {},
        h('div', { class: 'card' }, h('h2', {}, t('brand')), imageField(d, 'site.logo', t('logo')), bil(d, 'site.name', t('siteName')), bil(d, 'site.tagline', t('tagline')), bil(d, 'site.footer', t('footer'))),
        h('div', { class: 'card' }, h('h2', {}, t('seoDesc')), bil(d, 'seo.description', '', { multiline: true, rows: 2, help: t('seoHelp') })),
        h('div', { class: 'card' }, h('h2', {}, t('social')), h('div', { class: 'hint' }, t('socialHint')),
          listEditor(d.social, t('social'), (s) => h('div', { class: 'grid2' }, textField(s, 'name', t('socialName')), textField(s, 'url', t('socialUrl'), { dir: 'ltr' })), { name: '', url: '' }, t('addSocial'))));
    });
  }

  /* ---- Sections & menu ---- */
  function viewSections() {
    return settingsPage((d) => {
      const defOrder = ['about', 'services', 'location'];
      if (!Array.isArray(d.sections)) d.sections = [];
      defOrder.forEach((id) => { if (!d.sections.some((s) => s.id === id)) d.sections.push({ id, show: true }); });
      d.sections = d.sections.filter((s) => defOrder.includes(s.id));
      const names = { about: 'secAbout', services: 'secServices', location: 'secLocation' };
      const box = h('div', { class: 'items' });
      const redraw = () => box.replaceChildren(...d.sections.map((s, i) => h('div', { class: 'item row' },
        h('b', {}, t(names[s.id])),
        h('div', { class: 'item-tools' },
          h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: s.show !== false, onchange: (e) => { s.show = e.target.checked; markDirty(); } }), t('visible')),
          h('button', { type: 'button', class: 'icon-btn', disabled: i === 0, title: t('moveUp'), onclick: () => { [d.sections[i - 1], d.sections[i]] = [d.sections[i], d.sections[i - 1]]; markDirty(); redraw(); } }, ico('up', 16)),
          h('button', { type: 'button', class: 'icon-btn', disabled: i === d.sections.length - 1, title: t('moveDown'), onclick: () => { [d.sections[i + 1], d.sections[i]] = [d.sections[i], d.sections[i + 1]]; markDirty(); redraw(); } }, ico('down', 16))))));
      redraw();
      d.servicesIntro = d.servicesIntro || {};
      return h('div', {},
        h('div', { class: 'card' }, h('h2', {}, t('sectionsT')), h('div', { class: 'hint' }, t('sectionsHint')), box),
        h('div', { class: 'card' }, h('h2', {}, t('svcIntro')), bil(d, 'servicesIntro.title', t('fTitle'), { ph: { ar: 'خدماتنا', en: 'Our Services' } }), bil(d, 'servicesIntro.subtitle', t('subtitle'), { multiline: true, rows: 2 })),
        h('div', { class: 'card' }, h('h2', {}, t('menuLabels')), h('div', { class: 'hint' }, t('menuHint')),
          bil(d, 'nav.home', t('secHome'), { ph: { ar: 'الرئيسية', en: 'Home' } }), bil(d, 'nav.about', t('secAbout'), { ph: { ar: 'من نحن', en: 'About' } }),
          bil(d, 'nav.services', t('secServices'), { ph: { ar: 'خدماتنا', en: 'Services' } }), bil(d, 'nav.location', t('secLocation'), { ph: { ar: 'الموقع', en: 'Location' } })));
    });
  }

  /* ---- About / Contact / Texts ---- */
  function viewAbout() {
    return settingsPage((d) => {
      d.about = d.about || {}; d.about.facts = d.about.facts || [];
      return h('div', {},
        h('div', { class: 'card' }, bil(d, 'about.title', t('fTitle')), bil(d, 'about.text', t('aboutText'), { multiline: true, rows: 8 }),
          bil(d, 'about.vision', t('vision'), { multiline: true, rows: 3 }), bil(d, 'about.mission', t('mission'), { multiline: true, rows: 3 }), imageField(d, 'about.image', t('aboutImage'))),
        h('div', { class: 'card' }, h('h2', {}, t('facts')), h('div', { class: 'hint' }, t('factsHint')),
          listEditor(d.about.facts, t('fact'), (f) => h('div', {}, textField(f, 'value', t('value'), { dir: 'ltr' }), bil(f, 'label', t('label'))), { value: '', label: { ar: '', en: '' } }, t('addFact'))));
    });
  }
  function viewContact() {
    return settingsPage((d) => {
      d.contact = d.contact || {};
      return h('div', {},
        h('div', { class: 'card' }, bil(d, 'contact.title', t('locTitle')), bil(d, 'contact.address', t('address')),
          h('div', { class: 'grid2' }, textField(d, 'contact.phone', t('phone'), { dir: 'ltr' }), textField(d, 'contact.email', t('email'), { type: 'email', dir: 'ltr' })),
          bil(d, 'contact.hours', t('hours'))),
        h('div', { class: 'card' }, textField(d, 'contact.mapsUrl', t('mapsUrl'), { dir: 'ltr' }),
          textField(d, 'contact.mapEmbed', t('mapEmbed'), { dir: 'ltr', help: t('mapEmbedHelp') }), textField(d, 'contact.mapQuery', t('mapQuery'), { dir: 'ltr' })));
    });
  }
  function viewLabels() {
    return settingsPage((d) => {
      d.labels = d.labels || {};
      return h('div', {}, h('div', { class: 'card' }, h('div', { class: 'hint' }, t('labelsHint')),
        Object.keys(SITE_TEXT).map((k) => { d.labels[k] = d.labels[k] || { ar: '', en: '' }; return bil(d, 'labels.' + k, SITE_TEXT[k][lang], { ph: SITE_TEXT[k], multiline: MULTILINE_LABELS.has(k), rows: 2 }); })));
    });
  }

  /* ---- Media / Account ---- */
  function viewMedia() {
    const grid = h('div', { class: 'media-grid' });
    const draw = () => grid.replaceChildren(...state.media.map((m) => h('div', { class: 'm' }, h('div', { class: 'pic', style: `background-image:${cssUrl(m.url)}` }),
      h('div', { class: 'meta' }, h('span', {}, m.name),
        h('span', { style: 'display:flex;gap:4px' },
          h('button', { class: 'icon-btn', title: t('copyUrl'), onclick: async () => { try { await navigator.clipboard.writeText(location.origin + m.url); toast(t('copied'), 'ok'); } catch (e) { toast(m.url); } } }, ico('ext', 14)),
          h('button', { class: 'icon-btn', title: t('delete'), onclick: async () => {
            if (!confirm(t('confirmDel'))) return;
            try { await api('DELETE', '/api/media/' + encodeURIComponent(m.name)); state.media = state.media.filter((x) => x.name !== m.name); draw(); } catch (e) { if (e.code !== 'unauthorized') toast(failMsg(e), 'err'); }
          } }, ico('trash', 14)))))));
    draw();
    return h('div', {}, dropzone(() => draw()), grid);
  }
  function viewAccount() {
    const cur = h('input', { type: 'password', autocomplete: 'current-password' }); const nxt = h('input', { type: 'password', autocomplete: 'new-password' });
    return h('div', { class: 'card', style: 'max-width:520px' }, h('h2', {}, t('changePw')),
      h('div', { class: 'field', style: 'margin-top:14px' }, h('label', {}, t('current')), cur),
      h('div', { class: 'field' }, h('label', {}, t('next')), nxt),
      h('button', { class: 'btn btn-primary', onclick: async () => {
        try { await api('POST', '/api/password', { current: cur.value, next: nxt.value }); cur.value = ''; nxt.value = ''; toast(t('pwChanged'), 'ok'); }
        catch (e) { if (e.code !== 'unauthorized') toast(e.code === 'invalid_credentials' || e.code === 'weak_password' ? t('pwBad') : failMsg(e), 'err'); }
      } }, t('changePw')));
  }

  /* ------------------------------------------------------------------ shell */
  const TABS = [['dashboard', viewDashboard], ['services', viewServices], ['slider', viewSlider], ['appearance', viewAppearance], ['brand', viewBrand], ['sections', viewSections], ['about', viewAbout], ['contact', viewContact], ['labels', viewLabels], ['media', viewMedia], ['account', viewAccount]];

  function setLang(l) {
    lang = l; try { localStorage.setItem('adminLang', l); } catch (e) { /* noop */ }
    render();
  }
  const langSwitch = () => h('div', { class: 'lang-sw' }, ['ar', 'en'].map((l) => h('button', { 'aria-pressed': String(lang === l), onclick: () => setLang(l) }, l.toUpperCase())));

  function goTab(id) { state.tab = id; state.navOpen = false; render(); window.scrollTo(0, 0); }

  function renderLogin(msg) {
    const user = h('input', { type: 'text', autocomplete: 'username', required: true, autofocus: true });
    const pass = h('input', { type: 'password', autocomplete: 'current-password', required: true });
    const err = h('div', { class: 'err', role: 'alert' }, msg || '');
    const form = h('form', {
      onsubmit: async (e) => {
        e.preventDefault(); err.textContent = '';
        try { await api('POST', '/api/login', { username: user.value, password: pass.value }); await boot(); }
        catch (er) { err.textContent = er.code === 'too_many_attempts' ? t('tooMany') : er.code === 'network' ? t('networkErr') : t('invalid'); pass.value = ''; }
      },
    }, h('div', { class: 'field', style: 'margin:0' }, h('label', {}, t('user')), user), h('div', { class: 'field', style: 'margin:0' }, h('label', {}, t('pass')), pass), err, h('button', { class: 'btn btn-primary', style: 'justify-content:center' }, t('signIn')));
    root.replaceChildren(h('div', { class: 'login' }, h('div', { class: 'login-card' },
      h('img', { src: '/uploads/logo.png', alt: '' }), h('h1', {}, t('title') + ' · ' + (lang === 'ar' ? 'مصرف الرشيد' : 'Rasheed Bank')), h('p', { class: 'sub' }, t('loginSub')), form,
      h('div', { style: 'margin-top:16px;display:flex;justify-content:center' }, h('div', { class: 'top-lang' }, langSwitch())))));
  }

  function render() {
    document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.title = t('title') + ' | Rasheed Bank';
    if (!state.user) return renderLogin();
    const cur = TABS.find((x) => x[0] === state.tab) || TABS[0];
    const side = h('aside', { class: 'side' + (state.navOpen ? ' open' : '') },
      h('div', { class: 'brand' }, h('img', { src: '/uploads/logo.png', alt: '' }), h('div', {}, h('b', {}, lang === 'ar' ? 'مصرف الرشيد' : 'Rasheed Bank'), h('small', {}, t('title')))),
      TABS.map(([id]) => h('button', { class: 'tab', 'aria-current': id === state.tab ? 'page' : null, onclick: () => goTab(id) }, ico(id === 'dashboard' ? 'dash' : id === 'services' ? 'svc' : id, 18), t(id))),
      h('div', { class: 'spacer' }),
      h('button', { class: 'tab', onclick: async () => { try { await api('POST', '/api/logout'); } catch (e) { /* noop */ } state.user = null; render(); } }, ico('out'), t('logout')));
    const actions = h('div', { class: 'actions' },
      h('span', { class: 'dirty-pill', hidden: !state.dirty }, t('unsaved')),
      h('div', { class: 'top-lang' }, langSwitch()),
      !window.__PREVIEW__ && h('a', { class: 'btn btn-line', href: '/', target: '_blank', rel: 'noopener' }, ico('ext', 16), t('viewSite')),
      cur[0] === 'services' && h('button', { class: 'btn btn-primary', onclick: () => openServiceEditor(null) }, ico('plus', 16), t('addService')));
    const main = h('main', { class: 'main' },
      h('div', { class: 'topbar' }, h('div', { style: 'display:flex;gap:10px;align-items:center' }, h('button', { class: 'icon-btn menu-btn', onclick: () => { state.navOpen = !state.navOpen; render(); }, 'aria-label': t('menu') }, ico('menu')), h('h1', {}, t(cur[0]))), actions),
      window.__PREVIEW__ && h('div', { class: 'card', style: 'background:#fff7dc' }, t('preview')),
      cur[1]());
    root.replaceChildren(h('div', { class: 'app' }, side, main));
  }

  async function boot() {
    try {
      const me = await api('GET', '/api/me'); state.user = me.user;
      state.content = await api('GET', '/api/admin/content'); state.draft = fill(clone(state.content.settings), DEFAULTS); state.dirty = false;
      try { await loadMedia(); } catch (e) { /* noop */ }
    } catch (e) { state.user = null; }
    render();
  }
  window.addEventListener('beforeunload', (e) => { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });
  boot();
})();
