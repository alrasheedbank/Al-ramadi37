/* Rasheed Bank – public website (single page, own router, AR / EN).
 * Everything visual is driven by /api/content → settings (see the admin panel). */
(() => {
  'use strict';

  /* --------------------------------------------------------------- strings */
  const UI = {
    ar: {
      home: 'الرئيسية', about: 'من نحن', services: 'خدماتنا', location: 'الموقع', menu: 'القائمة', close: 'إغلاق',
      learn: 'معلومات أكثر', back: 'العودة إلى الخدمات', ourServices: 'خدماتنا', findUs: 'موقعنا',
      other: 'خدمات أخرى', interested: 'هل تودّ الاستفسار؟', visit: 'يسعد موظفونا بخدمتكم في الفرع. تفضّلوا بزيارتنا للحصول على التفاصيل والمستندات المطلوبة.',
      vision: 'رؤيتنا', mission: 'رسالتنا', address: 'العنوان', phone: 'الهاتف', email: 'البريد الإلكتروني', hours: 'ساعات الدوام',
      openMaps: 'افتح في خرائط جوجل', quick: 'روابط سريعة', contact: 'تواصل معنا', scroll: 'اكتشف',
      prev: 'السابق', next: 'التالي', top: 'إلى الأعلى', noServices: 'لا توجد خدمات لعرضها حالياً.', notFound: 'لم يتم العثور على هذه الخدمة.',
      error: 'تعذّر تحميل المحتوى. يرجى المحاولة مرة أخرى.', retry: 'إعادة المحاولة', est: 'منذ', follow: 'تابعونا',
    },
    en: {
      home: 'Home', about: 'About', services: 'Services', location: 'Location', menu: 'Menu', close: 'Close',
      learn: 'Learn more', back: 'Back to services', ourServices: 'Our services', findUs: 'Find us',
      other: 'Other services', interested: 'Have a question?', visit: 'Our team is happy to help at the branch. Visit us for details and the documents you will need.',
      vision: 'Our vision', mission: 'Our mission', address: 'Address', phone: 'Phone', email: 'Email', hours: 'Opening hours',
      openMaps: 'Open in Google Maps', quick: 'Quick links', contact: 'Contact', scroll: 'Discover',
      prev: 'Previous', next: 'Next', top: 'Back to top', noServices: 'No services to show yet.', notFound: 'This service could not be found.',
      error: 'Could not load the content. Please try again.', retry: 'Retry', est: 'Since', follow: 'Follow us',
    },
  };
  const ICON = {
    arrow: '<svg class="arrow" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    chev: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg>',
    chevR: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
    pin: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/></svg>',
    pinBig: '<svg width="54" height="54" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s7-6.2 7-12a7 7 0 10-14 0c0 5.8 7 12 7 12z"/><circle cx="12" cy="10" r="2.6"/></svg>',
    phone: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/></svg>',
    mail: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>',
    clock: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    up: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg>',
  };
  const SEC_IDS = ['about', 'services', 'location'];
  const SHAPES = ['arch', 'pointed', 'rounded', 'circle', 'oval', 'pill', 'leaf', 'hexagon', 'rect'];
  const CLIP_SHAPES = ['hexagon', 'pointed'];
  const POS = { top: 'center top', bottom: 'center bottom', left: 'left center', right: 'right center' };

  /* --------------------------------------------------------------- helpers */
  const state = { lang: 'ar', data: null, route: { type: 'home', anchor: '' }, slider: null, closeMenu: null };
  try { state.lang = localStorage.getItem('lang') === 'en' ? 'en' : 'ar'; } catch (e) { /* storage blocked (sandboxed frames) */ }
  const qs = new URLSearchParams(location.search);
  if (qs.get('lang') === 'en' || qs.get('lang') === 'ar') state.lang = qs.get('lang');
  const CAN_URL = /^https?:$/.test(location.protocol); // history/hash updates only where they are safe

  const settings = () => (state.data && state.data.settings) || {};
  const T = (o) => (o && (o[state.lang] || o.ar || o.en)) || '';
  const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
  /** UI string: panel override ("Texts" page) → built-in default */
  const S = (k) => {
    const o = (settings().labels || {})[k];
    const v = o && typeof o[state.lang] === 'string' ? o[state.lang].trim() : '';
    return v || UI[state.lang][k] || '';
  };
  const navLabel = (id) => {
    const o = (settings().nav || {})[id];
    const v = o && typeof o[state.lang] === 'string' ? o[state.lang].trim() : '';
    return v || S(id);
  };

  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'html') e.innerHTML = v; // only ever called with the constant ICON strings above
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      e.append(kid.nodeType ? kid : document.createTextNode(kid));
    }
    return e;
  }
  const icon = (name, cls) => h('span', { class: cls || 'ico', html: ICON[name], 'aria-hidden': 'true' });
  const safeImg = (u) => (/^(\/uploads\/[\w.\-]+|https:\/\/[^\s]+|data:image\/)/.test(u || '') ? u : '');
  const safeLink = (u) => (/^(#[\w\-\/]*|\/[\w\-\/.]*|https:\/\/[^\s]+|tel:[\d+\-() ]+|mailto:[^\s]+)$/.test(u || '') ? u : '');
  const el = (s, r = document) => r.querySelector(s);
  const app = el('#app');
  const safeDecode = (s) => { try { return decodeURIComponent(s); } catch (e) { return s; } };

  function linkEl(link, cls, ...kids) {
    const href = safeLink(link) || '#home';
    const ext = /^https:/.test(href);
    return h('a', { class: cls, href, target: ext ? '_blank' : null, rel: ext ? 'noopener noreferrer' : null }, ...kids);
  }

  function paragraphs(text) {
    const box = h('div', { class: 'prose' });
    String(text || '').split(/\n{2,}/).forEach((block) => {
      const lines = block.split('\n').filter((l) => l.trim());
      if (!lines.length) return;
      if (lines.every((l) => /^\s*[-•]\s+/.test(l))) {
        box.append(h('ul', {}, lines.map((l) => h('li', {}, l.replace(/^\s*[-•]\s+/, '')))));
      } else if (/^##\s+/.test(lines[0])) {
        box.append(h('h3', {}, lines[0].replace(/^##\s+/, '')));
        if (lines.length > 1) box.append(h('p', {}, lines.slice(1).join(' ')));
      } else box.append(h('p', {}, lines.join(' ')));
    });
    return box;
  }

  function setDir() {
    document.documentElement.lang = state.lang;
    document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
  }

  /** colours / corner radius chosen in the panel (Appearance) */
  function applyTheme() {
    const t = settings().theme || {};
    const st = document.documentElement.style;
    const hex = (v) => (/^#[0-9a-f]{6}$/i.test(v || '') ? v : '');
    const map = { accent: '--gold-2', accentLight: '--gold-3', accentDeep: '--gold', dark: '--brown', paper: '--ivory', cream: '--cream' };
    for (const [k, cssVar] of Object.entries(map)) { const v = hex(t[k]); if (v) st.setProperty(cssVar, v); else st.removeProperty(cssVar); }
    const d = hex(t.dark);
    if (d) {
      const n = parseInt(d.slice(1), 16); const rgb = [n >> 16, (n >> 8) & 255, n & 255];
      st.setProperty('--brown-rgb', rgb.join(', '));
      st.setProperty('--brown-2', '#' + rgb.map((c) => Math.round(c + (255 - c) * 0.1).toString(16).padStart(2, '0')).join(''));
    } else { st.removeProperty('--brown-rgb'); st.removeProperty('--brown-2'); }
    const r = Number(t.radius);
    if (t.radius !== '' && t.radius != null && Number.isFinite(r)) st.setProperty('--radius', clamp(r, 0, 40) + 'px'); else st.removeProperty('--radius');
    const meta = el('meta[name="theme-color"]'); if (meta && d) meta.setAttribute('content', d);
  }

  /** ordered sections [{id, show}] – order and visibility come from the panel */
  function sections() {
    const list = Array.isArray(settings().sections) ? settings().sections : [];
    const seen = new Set(); const out = [];
    list.forEach((s) => { if (s && SEC_IDS.includes(s.id) && !seen.has(s.id)) { seen.add(s.id); out.push({ id: s.id, show: s.show !== false }); } });
    SEC_IDS.forEach((id) => { if (!seen.has(id)) out.push({ id, show: true }); });
    return out;
  }
  const visibleSections = () => sections().filter((s) => s.show).map((s) => s.id);

  /* ----------------------------------------------------------- data loading */
  async function load() {
    const r = await fetch('/api/content', { headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error('http ' + r.status);
    state.data = await r.json();
  }

  /* ---------------------------------------------------------------- reveals */
  let io;
  function observeReveals(root) {
    const nodes = root.querySelectorAll('[data-reveal]');
    if (!('IntersectionObserver' in window)) { nodes.forEach((n) => { n.classList.add('in'); n.querySelectorAll('[data-count]').forEach(countUp); if (n.hasAttribute('data-count')) countUp(n); }); return; }
    io = io || new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (!en.isIntersecting) return;
        en.target.classList.add('in');
        io.unobserve(en.target);
        en.target.querySelectorAll('[data-count]').forEach(countUp);
        if (en.target.hasAttribute('data-count')) countUp(en.target);
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -4% 0px' });
    nodes.forEach((n) => io.observe(n));
  }
  function countUp(node) {
    if (node.dataset.done) return; node.dataset.done = '1';
    const target = Number(node.dataset.count); const pre = node.dataset.pre || ''; const suf = node.dataset.suf || '';
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { node.textContent = pre + target + suf; return; }
    const t0 = performance.now(); const dur = 1600;
    const tick = (t) => {
      const p = Math.min(1, (t - t0) / dur); const e = 1 - Math.pow(1 - p, 4);
      node.textContent = pre + Math.round(target * e) + suf;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  /* ----------------------------------------------------------------- header */
  function buildHeader() {
    const site = settings().site || {};
    const logo = safeImg(site.logo) || '/uploads/logo.png';
    const links = ['home'].concat(visibleSections());

    const burger = h('button', { class: 'burger', 'aria-label': S('menu'), 'aria-expanded': 'false', 'aria-controls': 'menu' }, h('span'), h('span'), h('span'));
    const header = h('header', { class: 'header' },
      h('div', { class: 'header-start' },
        h('div', { class: 'lang', role: 'group', 'aria-label': 'Language' },
          ['ar', 'en'].map((l) => h('button', { 'aria-pressed': String(state.lang === l), lang: l, onclick: () => switchLang(l) }, l === 'ar' ? 'AR' : 'EN')))),
      h('div', { class: 'header-end' },
        burger,
        h('a', { class: 'brand', href: '#home', 'aria-label': T(site.name) }, h('img', { src: logo, alt: T(site.name) }))));

    const backdrop = h('div', { class: 'menu-backdrop' });
    const menu = h('aside', { class: 'menu pattern', id: 'menu', 'aria-label': S('menu'), 'aria-hidden': 'true' },
      h('div', { class: 'menu-top' },
        h('img', { src: logo, alt: '' }),
        h('button', { class: 'menu-close', 'aria-label': S('close') }, '×')),
      h('nav', {}, links.map((id, i) => h('a', { href: '#' + id, 'data-nav': id, style: `--i:${i}` }, h('small', {}, '0' + (i + 1)), navLabel(id)))),
      h('div', { class: 'menu-foot' }, T(site.tagline)));

    const setMenu = (open) => {
      menu.classList.toggle('open', open); backdrop.classList.toggle('open', open);
      burger.setAttribute('aria-expanded', String(open)); menu.setAttribute('aria-hidden', String(!open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (open) el('.menu-close', menu).focus({ preventScroll: true });
    };
    burger.addEventListener('click', () => setMenu(!menu.classList.contains('open')));
    backdrop.addEventListener('click', () => setMenu(false));
    el('.menu-close', menu).addEventListener('click', () => setMenu(false));
    menu.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => setMenu(false)));
    state.closeMenu = () => { if (menu.classList.contains('open')) setMenu(false); };
    return [header, backdrop, menu];
  }

  function switchLang(l) {
    if (l === state.lang) return;
    state.lang = l; try { localStorage.setItem('lang', l); } catch (e) { /* noop */ }
    render({ keepScroll: true });
  }

  /* ------------------------------------------------------------------- hero */
  function foundedYear() {
    const f = ((settings().about || {}).facts || []).map((x) => String(x.value || '').trim()).find((v) => /^\d{4}$/.test(v));
    return f || '1988';
  }
  function buildHero() {
    const s = settings(); const site = s.site || {}; const hc = s.hero || {};
    const slides = (hc.slides || []).filter((x) => x && (x.image || T(x.title)));
    const full = hc.layout === 'full';
    const shape = SHAPES.includes(hc.shape) ? hc.shape : 'arch';
    const effect = ['fade', 'zoom', 'slide'].includes(hc.effect) ? hc.effect : 'zoom';
    const interval = clamp(Number(hc.interval) || 6.5, 3, 20) * 1000;
    const auto = hc.autoplay !== false;
    const overlay = clamp(Number(hc.overlay) || 0.9, 0.3, 0.97);

    const imgs = slides.map((sl, i) => h('img', {
      src: safeImg(sl.image), alt: T(sl.title), class: i === 0 ? 'active' : '', loading: i === 0 ? 'eager' : 'lazy',
      style: POS[sl.position] ? `object-position:${POS[sl.position]}` : null,
    }));
    const stage = h('div', { class: (full ? 'hero-bg ' : 'arch ') + 'fx-' + effect }, imgs);

    const texts = h('div', { class: 'slide-texts' }, slides.map((sl, i) => h('div', { class: 'slide-text' + (i === 0 ? ' active' : '') },
      h('h1', {}, T(sl.title)), h('p', {}, T(sl.subtitle)))));
    const dots = h('div', { class: 'dots', role: 'tablist' }, slides.map((_, i) => h('button', { class: 'dot' + (i === 0 ? ' active' : ''), 'aria-label': (i + 1) + '/' + slides.length, style: `--dur:${interval}ms` })));

    const b = hc.buttons || {};
    const p1 = b.primary || {}; const p2 = b.secondary || {};
    const buttons = hc.showButtons === false ? null : h('div', { class: 'hero-cta' },
      linkEl(p1.link || '#services', 'btn btn-gold', T(p1.label) || S('ourServices'), icon('arrow', 'arrow-wrap')),
      linkEl(p2.link || '#location', 'btn btn-ghost', icon('pin', 'ico'), T(p2.label) || S('findUs')));

    const media = full ? null : h('div', {
      class: `hero-media shape-${shape}` + (CLIP_SHAPES.includes(shape) ? ' clip' : ''), 'data-size': ['s', 'm', 'l'].includes(hc.size) ? hc.size : 'm', 'data-ratio': ['portrait', 'square', 'landscape'].includes(hc.ratio) ? hc.ratio : 'portrait',
    }, h('div', { class: 'arch-ring' }), stage,
      hc.badge !== false && h('div', { class: 'hero-badge' }, h('b', {}, foundedYear()), h('span', {}, S('est'), h('br'), T(site.name))));

    const showArrows = hc.arrows !== false && slides.length > 1; const showDots = hc.dots !== false && slides.length > 1;
    const controls = (showArrows || showDots || hc.scrollCue !== false) && h('div', { class: 'hero-controls' },
      showDots && dots,
      showArrows && h('button', { class: 'nav-btn', 'aria-label': S('prev'), onclick: () => go(-1), html: ICON.chev }),
      showArrows && h('button', { class: 'nav-btn', 'aria-label': S('next'), onclick: () => go(1), html: ICON.chevR }),
      hc.scrollCue !== false && h('div', { class: 'scroll-cue' }, S('scroll'), h('i')));

    const hero = h('section', { id: 'home', class: 'hero' + (full ? ' full' : '') + (hc.mediaSide === 'start' ? ' media-start' : '') + (auto ? '' : ' noauto'), style: `--ov:${overlay}`, 'data-height': ['tall', 'medium'].includes(hc.height) ? hc.height : null },
      full && stage, full && h('div', { class: 'hero-veil' }),
      h('div', { class: 'pattern-layer pattern' }),
      hc.coins !== false && h('div', { class: 'coins', 'aria-hidden': 'true' }, [0, 1, 2, 3, 4, 5, 6].map((i) => h('i', { class: 'coin-f', style: `inset-inline-start:${8 + i * 13}%;--s:${14 + (i * 7) % 22}px;--t:${14 + (i * 3) % 9}s;--d:${-i * 2.3}s` }))),
      h('div', { class: 'hero-inner' },
        h('div', { class: 'hero-text' }, h('div', { class: 'eyebrow' }, T(site.name)), texts, buttons),
        media),
      controls);

    // slider logic
    let cur = 0; let timer = null;
    const tx = [...texts.children]; const dt = [...dots.children];
    function show(n) {
      if (!slides.length) return;
      cur = (n + slides.length) % slides.length;
      imgs.forEach((x, i) => {
        x.classList.toggle('before', i < cur);
        if (effect === 'zoom') { x.classList.remove('active'); if (i === cur) { void x.offsetWidth; x.classList.add('active'); } }
        else x.classList.toggle('active', i === cur);
      });
      tx.forEach((x, i) => x.classList.toggle('active', i === cur));
      dt.forEach((x, i) => { x.classList.remove('active'); if (i === cur) { void x.offsetWidth; x.classList.add('active'); } });
    }
    function go(d) { show(cur + d); restart(); }
    function restart() { clearInterval(timer); if (auto && slides.length > 1) timer = setInterval(() => show(cur + 1), interval); }
    dt.forEach((d, i) => d.addEventListener('click', () => { show(i); restart(); }));
    if (matchMedia('(hover: hover)').matches) {
      hero.addEventListener('mouseenter', () => { clearInterval(timer); hero.classList.add('paused'); });
      hero.addEventListener('mouseleave', () => { hero.classList.remove('paused'); restart(); });
    }
    let sx = null;
    hero.addEventListener('touchstart', (e) => { sx = e.touches[0].clientX; }, { passive: true });
    hero.addEventListener('touchend', (e) => { if (sx == null) return; const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50) go(dx < 0 ? 1 : -1); sx = null; }, { passive: true });
    restart();
    state.slider = () => clearInterval(timer);
    return hero;
  }

  /* ------------------------------------------------------------------ about */
  function tokens(v) {
    const years = Math.max(0, new Date().getFullYear() - Number(foundedYear()));
    return String(v || '').replace(/\{years\}/g, years).replace(/\{services\}/g, state.data.services.length);
  }
  function buildAbout() {
    const a = settings().about || {}; const site = settings().site || {};
    const logo = safeImg(site.logo) || '/uploads/logo.png';
    const facts = (a.facts || []).map((f, i) => {
      const val = tokens(f.value); const m = /^(\D*)(\d[\d,]*)(\D*)$/.exec(val);
      const b = m ? h('b', { 'data-count': m[2].replace(/,/g, ''), 'data-pre': m[1], 'data-suf': m[3] }, m[1] + '0' + m[3]) : h('b', {}, val);
      return h('div', { class: 'fact', 'data-reveal': 'zoom', style: `--d:${i * 0.1}s` }, b, h('span', {}, T(f.label)));
    });
    return h('section', { id: 'about', class: 'section about' }, h('div', { class: 'wrap' },
      h('div', { class: 'about-grid' },
        h('div', { class: 'about-photo', 'data-reveal': 'start' },
          h('img', { src: safeImg(a.image), alt: T(a.title), loading: 'lazy' }),
          h('div', { class: 'coin3d', 'aria-hidden': 'true' }, h('div', { class: 'coin3d-in' }, h('img', { src: logo, alt: '' }), h('img', { src: logo, alt: '' })))),
        h('div', { class: 'about-text', 'data-reveal': 'end' },
          h('div', { class: 'eyebrow' }, T(site.name)),
          h('h2', {}, T(a.title)),
          String(T(a.text)).split(/\n{2,}/).filter(Boolean).map((p) => h('p', { class: 'para' }, p)),
          h('div', { class: 'vm' },
            T(a.vision) && h('div', {}, h('h4', {}, S('vision')), h('p', {}, T(a.vision))),
            T(a.mission) && h('div', {}, h('h4', {}, S('mission')), h('p', {}, T(a.mission)))))),
      facts.length ? h('div', { class: 'facts' }, facts) : null));
  }

  /* --------------------------------------------------------------- services */
  function serviceCard(sv, i) {
    const href = '#/service/' + encodeURIComponent(sv.slug);
    return h('article', { class: 'card', 'data-reveal': '', style: `--d:${(i % 3) * 0.1}s` },
      h('a', { class: 'card-img', href, tabindex: '-1', 'aria-hidden': 'true' },
        h('span', { class: 'card-no' }, String(i + 1).padStart(2, '0')),
        h('img', { src: safeImg(sv.image), alt: '', loading: 'lazy' })),
      h('div', { class: 'card-body' },
        T(sv.category) && h('span', { class: 'chip' }, T(sv.category)),
        h('h3', {}, T(sv.name)), h('p', {}, T(sv.short)),
        h('a', { class: 'btn btn-dark', href }, S('learn'), icon('arrow', 'arrow-wrap'))));
  }
  function buildServices() {
    const intro = settings().servicesIntro || {};
    const list = state.data.services;
    return h('section', { id: 'services', class: 'section services' }, h('div', { class: 'wrap' },
      h('div', { class: 'sec-head', 'data-reveal': '' }, h('div', { class: 'orn' }, h('i')), h('h2', {}, T(intro.title) || S('ourServices')), T(intro.subtitle) && h('p', {}, T(intro.subtitle))),
      list.length ? h('div', { class: 'grid' }, list.map(serviceCard)) : h('p', { class: 'empty' }, S('noServices'))));
  }

  /* --------------------------------------------------------------- location */
  function mapSrc(c) {
    if (c.mapEmbed && /^https:\/\/(www|maps)\.google\.com\/maps/.test(c.mapEmbed)) return c.mapEmbed;
    const query = c.mapQuery || T(c.address); if (!query) return '';
    return 'https://maps.google.com/maps?q=' + encodeURIComponent(query) + '&hl=' + state.lang + '&z=16&output=embed';
  }
  function buildLocation() {
    const c = settings().contact || {};
    const item = (ic, label, node) => h('div', { class: 'loc-item' }, h('div', { class: 'loc-ico' }, icon(ic)), h('div', {}, h('h4', {}, label), node));
    const src = mapSrc(c);
    return h('section', { id: 'location', class: 'section location pattern' }, h('div', { class: 'wrap' },
      h('div', { class: 'sec-head', 'data-reveal': '' }, h('div', { class: 'orn' }, h('i')), h('h2', {}, T(c.title) || S('findUs'))),
      h('div', { class: 'loc-grid' },
        h('div', { class: 'loc-card', 'data-reveal': 'start' },
          T(c.address) && item('pin', S('address'), h('p', {}, T(c.address))),
          c.phone && item('phone', S('phone'), h('a', { href: 'tel:' + c.phone.replace(/[^\d+]/g, '') }, c.phone)),
          c.email && item('mail', S('email'), h('a', { href: 'mailto:' + c.email }, c.email)),
          T(c.hours) && item('clock', S('hours'), h('p', {}, T(c.hours))),
          c.mapsUrl && h('div', { class: 'hero-cta' }, h('a', { class: 'btn btn-gold', href: c.mapsUrl, target: '_blank', rel: 'noopener noreferrer' }, icon('pin'), S('openMaps')))),
        h('div', { class: 'map-frame', 'data-reveal': 'end' },
          h('div', { class: 'map-fallback' }, h('div', {}, icon('pinBig', 'ico'), h('div', {}, T(c.address)))),
          src && h('iframe', { src, title: S('findUs'), loading: 'lazy', referrerpolicy: 'no-referrer-when-downgrade', allowfullscreen: true })))));
  }

  /* ----------------------------------------------------------------- footer */
  function buildFooter() {
    const site = settings().site || {}; const c = settings().contact || {};
    const social = (settings().social || []).filter((x) => x && /^https:\/\//.test(x.url || '') && (x.name || '').trim());
    return h('footer', { class: 'footer' },
      h('div', { class: 'foot-grid' },
        h('div', {}, h('div', { class: 'foot-brand' }, h('img', { src: safeImg(site.logo) || '/uploads/logo.png', alt: '' }), h('div', {}, h('b', {}, T(site.name)), h('span', {}, T(site.tagline)))),
          social.length ? h('div', { class: 'social', 'aria-label': S('follow') }, social.map((x) => h('a', { href: x.url, target: '_blank', rel: 'noopener noreferrer' }, x.name))) : null),
        h('div', {}, h('h5', {}, S('quick')), h('ul', {}, ['home'].concat(visibleSections()).map((id) => h('li', {}, h('a', { href: '#' + id }, navLabel(id)))))),
        h('div', {}, h('h5', {}, S('contact')), h('ul', {}, T(c.address) && h('li', {}, T(c.address)), c.phone && h('li', {}, h('a', { href: 'tel:' + c.phone.replace(/[^\d+]/g, '') }, c.phone)), c.email && h('li', {}, h('a', { href: 'mailto:' + c.email }, c.email))))),
      h('div', { class: 'foot-bottom' }, h('span', {}, '© ' + new Date().getFullYear() + ' ' + T(site.name) + '. ' + T(site.footer))));
  }

  /* ------------------------------------------------------------ detail view */
  function openLightbox(src) {
    const close = () => { ov.remove(); document.removeEventListener('keydown', onKey); };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    const ov = h('div', { class: 'lightbox', role: 'dialog', 'aria-modal': 'true', onclick: close }, h('img', { src, alt: '' }), h('button', { 'aria-label': S('close') }, '×'));
    document.addEventListener('keydown', onKey); document.body.append(ov);
  }
  function buildDetail(sv) {
    const c = settings().contact || {};
    const others = state.data.services.filter((x) => x.id !== sv.id).slice(0, 3);
    const img = safeImg(sv.image);
    const gallery = (sv.gallery || []).map(safeImg).filter(Boolean);
    return h('div', { class: 'view detail' },
      h('section', { class: 'detail-hero' },
        h('div', { class: 'bg', style: img ? `background-image:url("${img}")` : '' }),
        h('div', { class: 'wrap' },
          h('a', { class: 'back', href: '#services' }, icon('chev'), S('back')),
          T(sv.category) && h('div', {}, h('span', { class: 'chip' }, T(sv.category))),
          h('h1', {}, T(sv.name)), h('p', {}, T(sv.short)))),
      h('div', { class: 'detail-body' },
        h('div', {},
          img && h('div', { class: 'detail-img', 'data-reveal': 'zoom' }, h('img', { src: img, alt: T(sv.name) })),
          h('div', { 'data-reveal': '' }, paragraphs(T(sv.details))),
          gallery.length ? h('div', { class: 'gallery' }, gallery.map((g) => h('button', { type: 'button', 'aria-label': T(sv.name), onclick: () => openLightbox(g) }, h('img', { src: g, alt: '', loading: 'lazy' })))) : null),
        h('aside', { class: 'aside', 'data-reveal': 'end' },
          h('h3', {}, S('interested')), h('p', {}, S('visit')), T(c.address) && h('p', {}, T(c.address)),
          h('a', { class: 'btn btn-gold', href: '#location' }, icon('pin'), S('findUs')),
          h('a', { class: 'btn btn-ghost', href: '#services' }, S('back')))),
      others.length ? h('section', { class: 'more' }, h('div', { class: 'wrap' }, h('h2', {}, S('other')), h('div', { class: 'grid' }, others.map((o) => serviceCard(o, state.data.services.indexOf(o)))))) : null);
  }

  /* ------------------------------------------------------------------- page */
  function page() {
    const s = settings(); const site = s.site || {};
    const frag = document.createDocumentFragment();
    const [header, backdrop, menu] = buildHeader();
    const main = h('main', { id: 'main' });
    const route = state.route;
    let title = T(site.name) + ' | ' + (state.lang === 'ar' ? 'Rasheed Bank' : 'مصرف الرشيد');
    if (route.type === 'service') {
      const sv = state.data.services.find((x) => x.slug === route.slug);
      if (sv) { main.append(buildDetail(sv)); title = T(sv.name) + ' | ' + T(site.name); }
      else main.append(h('div', { class: 'view loading' }, h('div', { style: 'text-align:center' }, h('p', {}, S('notFound')), h('p', { style: 'margin-top:14px' }, h('a', { class: 'btn btn-dark', href: '#services' }, S('back'))))));
    } else {
      main.classList.add('home');
      const builders = { about: buildAbout, services: buildServices, location: buildLocation };
      main.append(buildHero(), ...sections().filter((x) => x.show).map((x) => builders[x.id]()));
    }
    document.title = title;
    const desc = T((s.seo || {}).description) || T((s.about || {}).vision);
    const md = el('meta[name="description"]'); if (md && desc) md.setAttribute('content', desc);
    const toTop = h('button', { class: 'to-top', 'aria-label': S('top'), html: ICON.up, onclick: () => scrollToY(0, true) });
    frag.append(h('div', { class: 'progress' }), header, backdrop, menu, main, buildFooter(), toTop);
    return frag;
  }

  /* ---------------------------------------------------------------- scrolling */
  function jump(y) { // instant, even though the page has scroll-behavior: smooth
    const d = document.documentElement; d.style.scrollBehavior = 'auto'; window.scrollTo(0, y); d.style.scrollBehavior = '';
  }
  function scrollToY(y, smooth) { if (smooth) window.scrollTo({ top: y, behavior: 'smooth' }); else jump(y); }
  function scrollToId(id, smooth) {
    const n = document.getElementById(id); if (!n) return false;
    scrollToY(Math.max(0, n.getBoundingClientRect().top + window.scrollY - 68), smooth); return true;
  }

  function render(opts = {}) {
    if (state.slider) state.slider();
    const y = window.scrollY;
    applyTheme(); setDir();
    document.body.style.overflow = '';
    app.replaceChildren(page());
    observeReveals(app);
    bindScroll();
    markActive();
    if (opts.keepScroll) jump(y);
  }

  let scrollBound = false;
  function bindScroll() {
    if (!scrollBound) { window.addEventListener('scroll', onScroll, { passive: true }); scrollBound = true; }
    onScroll();
  }
  function onScroll() {
    const hd = el('.header'); if (!hd) return;
    const y = window.scrollY;
    hd.classList.toggle('solid', y > (state.route.type === 'service' ? 220 : 60));
    const doc = document.documentElement; const max = doc.scrollHeight - doc.clientHeight;
    const pr = el('.progress'); if (pr) pr.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
    const tt = el('.to-top'); if (tt) tt.classList.toggle('show', y > 700);
    markActive();
  }
  function markActive() {
    const links = document.querySelectorAll('[data-nav]'); if (!links.length) return;
    let active = 'home';
    if (state.route.type === 'service') active = 'services';
    else visibleSections().forEach((id) => { const n = document.getElementById(id); if (n && n.getBoundingClientRect().top < window.innerHeight * 0.4) active = id; });
    links.forEach((a) => a.classList.toggle('active', a.dataset.nav === active));
  }

  /* ----------------------------------------------------------------- routing
   * We never rely on the browser's own #fragment navigation: inside sandboxed
   * viewers / previews it can reload or blank the page. Clicks on in-page links
   * are handled here; the address bar is only updated when that is safe.      */
  const routeKey = (r) => (r.type === 'service' ? 's:' + r.slug : 'h:' + (r.anchor || ''));
  function parseHash() {
    const m = /^#\/service\/([^/?#]+)/.exec(location.hash || '');
    if (m) return { type: 'service', slug: safeDecode(m[1]) };
    const a = safeDecode((location.hash || '').replace(/^#/, ''));
    return { type: 'home', anchor: /^[\w\-]+$/.test(a) ? a : '' };
  }
  function pushUrl(r) {
    if (!CAN_URL) return;
    const hash = r.type === 'service' ? '#/service/' + encodeURIComponent(r.slug) : (r.anchor && r.anchor !== 'home' ? '#' + r.anchor : '');
    if ((location.hash || '') === hash) return;
    try { history.pushState(null, '', location.pathname + location.search + hash); } catch (e) { /* not allowed here – in-memory navigation still works */ }
  }
  function navigate(route, opts = {}) {
    const prev = state.route; state.route = route;
    if (opts.push !== false) pushUrl(route);
    if (state.closeMenu) state.closeMenu();
    if (route.type === 'service') { render(); jump(0); return; }
    const wasHome = prev.type === 'home';
    if (!wasHome) render();
    if (!route.anchor || route.anchor === 'home') scrollToY(0, wasHome);
    else if (!scrollToId(route.anchor, wasHome)) scrollToY(0, false);
  }
  function onUrlChange() {
    if (!state.data) return;
    const r = parseHash();
    if (routeKey(r) === routeKey(state.route)) return;
    navigate(r, { push: false });
  }
  document.addEventListener('click', (e) => {
    if (e.defaultPrevented || e.button > 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href^="#"]');
    if (!a || !state.data) return;
    e.preventDefault();
    const href = a.getAttribute('href') || '#';
    const m = /^#\/service\/([^/?#]+)/.exec(href);
    navigate(m ? { type: 'service', slug: safeDecode(m[1]) } : { type: 'home', anchor: href.replace(/^#/, '') });
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && state.closeMenu) state.closeMenu(); });
  window.addEventListener('popstate', onUrlChange);
  window.addEventListener('hashchange', onUrlChange);

  /* ------------------------------------------------------------------- boot */
  async function start() {
    app.append(h('div', { class: 'loading' }, '…'));
    try { await load(); }
    catch (e) {
      app.replaceChildren(h('div', { class: 'loading' }, h('div', { style: 'text-align:center' }, h('p', {}, UI[state.lang].error), h('button', { class: 'btn btn-dark', onclick: () => location.reload() }, UI[state.lang].retry))));
      finishSplash(true); return;
    }
    const spl = settings().splash || {};
    const off = spl.enabled === false;
    try { if (off) localStorage.setItem('splashOff', '1'); else localStorage.removeItem('splashOff'); } catch (e) { /* noop */ }
    if (off) document.documentElement.classList.add('no-splash');
    const sn = el('.splash-name'); if (sn && T(spl.text)) sn.textContent = T(spl.text);
    document.documentElement.style.setProperty('--sky', 'url("/assets/hero-sky.jpg")');
    state.route = parseHash();
    render();
    if (state.route.type === 'home' && state.route.anchor && state.route.anchor !== 'home') setTimeout(() => scrollToId(state.route.anchor, false), 60);
    finishSplash(false);
  }

  function finishSplash(immediate) {
    const sp = document.getElementById('splash'); if (!sp) return;
    if (immediate || document.documentElement.classList.contains('no-splash')) { sp.remove(); return; }
    try { sessionStorage.setItem('splashed', '1'); } catch (e) { /* noop */ }
    document.body.style.overflow = 'hidden';
    setTimeout(() => {
      sp.classList.add('hide'); document.body.style.overflow = '';
      setTimeout(() => sp.remove(), 1300);
    }, 1900);
  }

  start();
})();
