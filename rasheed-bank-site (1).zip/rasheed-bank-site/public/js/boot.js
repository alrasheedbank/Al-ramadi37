/* Runs before first paint: decide whether the intro splash plays. */
(function () {
  var skip = false;
  try { skip = sessionStorage.getItem('splashed') === '1' || localStorage.getItem('splashOff') === '1'; } catch (e) { /* storage blocked */ }
  if (skip || /[?&]nosplash/.test(location.search)) document.documentElement.classList.add('no-splash');
})();
